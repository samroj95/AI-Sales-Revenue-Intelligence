import React, { useEffect, useState } from "react";
import api from "../api/client";
import KpiCard from "../components/KpiCard.jsx";
import RevenueChart from "../components/RevenueChart.jsx";
import AnomalyTable from "../components/AnomalyTable.jsx";

export default function Dashboard() {
  const [hotels, setHotels] = useState([]);
  const [hotelId, setHotelId] = useState(null);
  const [kpis, setKpis] = useState(null);
  const [forecastData, setForecastData] = useState(null);
  const [anomalyData, setAnomalyData] = useState(null);
  const [topHotels, setTopHotels] = useState([]);
  const [channelMix, setChannelMix] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get("/hotels").then((res) => {
      setHotels(res.data);
      if (res.data.length) setHotelId(res.data[0].id);
    });
    api.get("/dashboard/top-hotels").then((res) => setTopHotels(res.data));
  }, []);

  useEffect(() => {
    if (!hotelId) return;
    setLoading(true);
    Promise.all([
      api.get("/revenue/kpis", { params: { hotel_id: hotelId } }),
      api.get(`/forecast/${hotelId}`, { params: { horizon_days: 14 } }),
      api.get(`/anomaly/${hotelId}`, { params: { method: "zscore" } }),
      api.get("/dashboard/channel-mix", { params: { hotel_id: hotelId } }),
    ])
      .then(([kpiRes, forecastRes, anomalyRes, channelRes]) => {
        setKpis(kpiRes.data);
        setForecastData(forecastRes.data);
        setAnomalyData(anomalyRes.data);
        setChannelMix(channelRes.data);
      })
      .finally(() => setLoading(false));
  }, [hotelId]);

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Executive Dashboard</h2>
          <p className="text-sm text-slate-400">
            Portfolio revenue performance, forecasts, and anomaly signals.
          </p>
        </div>
        <select
          value={hotelId || ""}
          onChange={(e) => setHotelId(Number(e.target.value))}
          className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white"
        >
          {hotels.map((h) => (
            <option key={h.id} value={h.id}>
              {h.name} — {h.city}
            </option>
          ))}
        </select>
      </div>

      {loading && <p className="text-slate-400">Loading dashboard data...</p>}

      {!loading && kpis && (
        <>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
            <KpiCard label="Total Revenue" value={`$${Math.round(kpis.total_revenue).toLocaleString()}`} />
            <KpiCard label="Avg Occupancy" value={kpis.avg_occupancy_rate} suffix="%" />
            <KpiCard label="Avg ADR" value={`$${kpis.avg_adr}`} />
            <KpiCard label="Avg RevPAR" value={`$${kpis.avg_revpar}`} />
            <KpiCard
              label="Cancellation Rate"
              value={kpis.cancellation_rate}
              suffix="%"
              accent="text-amber-400"
            />
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-900 p-6">
            <h3 className="mb-4 text-sm font-semibold text-slate-200">
              Revenue History &amp; 14-Day Forecast{" "}
              <span className="ml-2 text-xs font-normal text-slate-500">
                ({forecastData?.method})
              </span>
            </h3>
            {forecastData && (
              <RevenueChart history={forecastData.history} forecast={forecastData.forecast} />
            )}
          </div>

          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <div className="rounded-xl border border-slate-800 bg-slate-900 p-6">
              <h3 className="mb-4 text-sm font-semibold text-slate-200">
                Anomaly Detection{" "}
                <span className="ml-2 text-xs font-normal text-slate-500">
                  ({anomalyData?.anomalies_detected} flagged)
                </span>
              </h3>
              {anomalyData && <AnomalyTable points={anomalyData.points} />}
            </div>

            <div className="rounded-xl border border-slate-800 bg-slate-900 p-6">
              <h3 className="mb-4 text-sm font-semibold text-slate-200">Channel Mix</h3>
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="text-xs uppercase tracking-wide text-slate-500">
                    <th className="pb-2">Channel</th>
                    <th className="pb-2">Bookings</th>
                    <th className="pb-2">Revenue</th>
                  </tr>
                </thead>
                <tbody>
                  {channelMix.map((c) => (
                    <tr key={c.channel} className="border-t border-slate-800">
                      <td className="py-2 capitalize text-slate-200">{c.channel.replace("_", " ")}</td>
                      <td className="py-2 text-slate-400">{c.booking_count}</td>
                      <td className="py-2 text-slate-200">
                        ${Math.round(c.total_revenue).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-900 p-6">
            <h3 className="mb-4 text-sm font-semibold text-slate-200">
              Top Performing Properties
            </h3>
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="text-xs uppercase tracking-wide text-slate-500">
                  <th className="pb-2">Hotel</th>
                  <th className="pb-2">City</th>
                  <th className="pb-2">Total Revenue</th>
                  <th className="pb-2">Avg RevPAR</th>
                </tr>
              </thead>
              <tbody>
                {topHotels.map((h) => (
                  <tr key={h.hotel_id} className="border-t border-slate-800">
                    <td className="py-2 text-slate-200">{h.hotel_name}</td>
                    <td className="py-2 text-slate-400">{h.city}</td>
                    <td className="py-2 text-slate-200">
                      ${Math.round(h.total_revenue).toLocaleString()}
                    </td>
                    <td className="py-2 text-slate-200">${h.avg_revpar}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
