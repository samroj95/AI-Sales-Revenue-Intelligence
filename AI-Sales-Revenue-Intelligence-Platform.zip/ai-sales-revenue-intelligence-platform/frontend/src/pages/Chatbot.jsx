import React, { useEffect, useState } from "react";
import api from "../api/client";

export default function Chatbot() {
  const [hotels, setHotels] = useState([]);
  const [hotelId, setHotelId] = useState(null);
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content:
        "Hi, I'm your AI revenue analyst. Ask me about KPIs, forecasts, anomalies, or revenue-management policy for any property.",
    },
  ]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);

  useEffect(() => {
    api.get("/hotels").then((res) => {
      setHotels(res.data);
      if (res.data.length) setHotelId(res.data[0].id);
    });
  }, []);

  async function sendMessage(e) {
    e.preventDefault();
    if (!input.trim()) return;
    const userMessage = { role: "user", content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setSending(true);

    try {
      const { data } = await api.post("/chatbot/query", {
        message: userMessage.content,
        hotel_id: hotelId,
      });
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: data.answer, meta: `${data.provider}/${data.model}` },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            err.response?.data?.detail ||
            "The AI assistant is temporarily unavailable. Please try again.",
        },
      ]);
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="flex h-full flex-col">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">AI Revenue Analyst</h2>
        <select
          value={hotelId || ""}
          onChange={(e) => setHotelId(Number(e.target.value))}
          className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white"
        >
          {hotels.map((h) => (
            <option key={h.id} value={h.id}>
              {h.name}
            </option>
          ))}
        </select>
      </div>

      <div className="flex-1 space-y-4 overflow-y-auto rounded-xl border border-slate-800 bg-slate-900 p-6">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-lg rounded-2xl px-4 py-3 text-sm ${
                m.role === "user"
                  ? "bg-brand-600 text-white"
                  : "bg-slate-800 text-slate-100"
              }`}
            >
              <p className="whitespace-pre-wrap">{m.content}</p>
              {m.meta && <p className="mt-2 text-xs text-slate-400">via {m.meta}</p>}
            </div>
          </div>
        ))}
        {sending && <p className="text-xs text-slate-500">AI analyst is thinking...</p>}
      </div>

      <form onSubmit={sendMessage} className="mt-4 flex gap-3">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="e.g. What was our RevPAR trend and were there any anomalies this month?"
          className="flex-1 rounded-lg border border-slate-700 bg-slate-900 px-4 py-3 text-sm text-white outline-none focus:border-brand-500"
        />
        <button
          type="submit"
          disabled={sending}
          className="rounded-lg bg-brand-600 px-6 py-3 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-60"
        >
          Send
        </button>
      </form>
    </div>
  );
}
