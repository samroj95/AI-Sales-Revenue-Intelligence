import React, { useEffect, useState } from "react";
import api from "../api/client";

export default function Bookings() {
  const [hotels, setHotels] = useState([]);
  const [hotelId, setHotelId] = useState(null);
  const [bookings, setBookings] = useState({ items: [], total: 0 });
  const [page, setPage] = useState(1);
  const pageSize = 10;

  useEffect(() => {
    api.get("/hotels").then((res) => {
      setHotels(res.data);
      if (res.data.length) setHotelId(res.data[0].id);
    });
  }, []);

  useEffect(() => {
    if (!hotelId) return;
    api
      .get("/bookings", { params: { hotel_id: hotelId, page, page_size: pageSize } })
      .then((res) => setBookings(res.data));
  }, [hotelId, page]);

  const totalPages = Math.max(1, Math.ceil(bookings.total / pageSize));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Bookings</h2>
        <select
          value={hotelId || ""}
          onChange={(e) => {
            setPage(1);
            setHotelId(Number(e.target.value));
          }}
          className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white"
        >
          {hotels.map((h) => (
            <option key={h.id} value={h.id}>
              {h.name}
            </option>
          ))}
        </select>
      </div>

      <div className="overflow-hidden rounded-xl border border-slate-800 bg-slate-900">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-800/50 text-xs uppercase tracking-wide text-slate-400">
            <tr>
              <th className="px-4 py-3">Guest</th>
              <th className="px-4 py-3">Channel</th>
              <th className="px-4 py-3">Check-in</th>
              <th className="px-4 py-3">Nights</th>
              <th className="px-4 py-3">Amount</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {bookings.items.map((b) => (
              <tr key={b.id} className="border-t border-slate-800">
                <td className="px-4 py-3 text-slate-200">{b.customer_name}</td>
                <td className="px-4 py-3 capitalize text-slate-400">{b.channel.replace("_", " ")}</td>
                <td className="px-4 py-3 text-slate-400">{b.check_in}</td>
                <td className="px-4 py-3 text-slate-400">{b.nights}</td>
                <td className="px-4 py-3 text-slate-200">${b.total_amount}</td>
                <td className="px-4 py-3">
                  <span className="rounded-full bg-slate-800 px-2 py-1 text-xs capitalize text-slate-300">
                    {b.status.replace("_", " ")}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between text-sm text-slate-400">
        <span>
          Page {page} of {totalPages} ({bookings.total} bookings)
        </span>
        <div className="space-x-2">
          <button
            disabled={page <= 1}
            onClick={() => setPage((p) => p - 1)}
            className="rounded-lg border border-slate-700 px-3 py-1 disabled:opacity-40"
          >
            Prev
          </button>
          <button
            disabled={page >= totalPages}
            onClick={() => setPage((p) => p + 1)}
            className="rounded-lg border border-slate-700 px-3 py-1 disabled:opacity-40"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
}
