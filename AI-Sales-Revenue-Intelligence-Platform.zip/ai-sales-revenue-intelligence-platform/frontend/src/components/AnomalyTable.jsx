import React from "react";

const SEVERITY_STYLES = {
  severe: "bg-red-500/20 text-red-400",
  moderate: "bg-amber-500/20 text-amber-400",
  normal: "bg-slate-700/40 text-slate-400",
};

export default function AnomalyTable({ points }) {
  const anomalies = points.filter((p) => p.is_anomaly);

  if (anomalies.length === 0) {
    return (
      <p className="text-sm text-slate-400">
        No anomalies detected in the current revenue history. 🎉
      </p>
    );
  }

  return (
    <table className="w-full text-left text-sm">
      <thead>
        <tr className="text-xs uppercase tracking-wide text-slate-500">
          <th className="pb-2">Date</th>
          <th className="pb-2">Revenue</th>
          <th className="pb-2">Z-score</th>
          <th className="pb-2">Severity</th>
        </tr>
      </thead>
      <tbody>
        {anomalies.map((a) => (
          <tr key={a.date} className="border-t border-slate-800">
            <td className="py-2 text-slate-200">{a.date}</td>
            <td className="py-2 text-slate-200">${a.total_revenue.toLocaleString()}</td>
            <td className="py-2 text-slate-400">{a.z_score}</td>
            <td className="py-2">
              <span
                className={`rounded-full px-2 py-1 text-xs font-medium ${SEVERITY_STYLES[a.severity]}`}
              >
                {a.severity}
              </span>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
