import React from "react";
import {
  Area,
  CartesianGrid,
  ComposedChart,
  Legend,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

/**
 * Combines actual revenue history with a forward-looking forecast band
 * (upper/lower confidence interval) in a single continuous chart so
 * revenue managers can visually see where "actual" ends and "predicted"
 * begins.
 */
export default function RevenueChart({ history, forecast }) {
  const historyData = history.map((h) => ({
    date: h.date,
    actual: Number(h.total_revenue),
  }));

  const forecastData = forecast.map((f) => ({
    date: f.date,
    forecast: f.forecast_revenue,
    range: [f.lower_bound, f.upper_bound],
  }));

  const combined = [...historyData, ...forecastData];

  return (
    <ResponsiveContainer width="100%" height={320}>
      <ComposedChart data={combined}>
        <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
        <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#94a3b8" }} minTickGap={30} />
        <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} />
        <Tooltip
          contentStyle={{ background: "#0f172a", border: "1px solid #1e293b" }}
          labelStyle={{ color: "#e2e8f0" }}
        />
        <Legend />
        <Area
          type="monotone"
          dataKey="range"
          fill="#3b6fe033"
          stroke="none"
          name="Forecast range"
        />
        <Line
          type="monotone"
          dataKey="actual"
          stroke="#38bdf8"
          strokeWidth={2}
          dot={false}
          name="Actual revenue"
        />
        <Line
          type="monotone"
          dataKey="forecast"
          stroke="#f59e0b"
          strokeWidth={2}
          strokeDasharray="6 4"
          dot={false}
          name="Forecast"
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
}
