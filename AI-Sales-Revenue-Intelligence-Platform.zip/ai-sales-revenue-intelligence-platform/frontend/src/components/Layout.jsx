import React from "react";
import { NavLink, Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

const NAV_ITEMS = [
  { to: "/", label: "Executive Dashboard", end: true },
  { to: "/bookings", label: "Bookings" },
  { to: "/chatbot", label: "AI Analyst" },
];

export default function Layout() {
  const { user, logout } = useAuth();

  return (
    <div className="flex h-screen bg-slate-950">
      <aside className="w-64 flex-shrink-0 border-r border-slate-800 bg-slate-900 p-6">
        <h1 className="mb-8 text-lg font-bold text-brand-500">
          Sales &amp; Revenue Intelligence
        </h1>
        <nav className="space-y-1">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `block rounded-lg px-4 py-2 text-sm font-medium transition ${
                  isActive
                    ? "bg-brand-600 text-white"
                    : "text-slate-300 hover:bg-slate-800"
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="mt-10 border-t border-slate-800 pt-4 text-xs text-slate-400">
          <p className="mb-2">
            Signed in as <span className="text-slate-200">{user?.full_name}</span>
          </p>
          <p className="mb-4 uppercase tracking-wide text-brand-500">{user?.role}</p>
          <button
            onClick={logout}
            className="w-full rounded-lg border border-slate-700 px-3 py-2 text-slate-300 hover:bg-slate-800"
          >
            Sign out
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto p-8">
        <Outlet />
      </main>
    </div>
  );
}
