import React from "react";

export default function KpiCard({ label, value, suffix = "", accent = "text-brand-500" }) {
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
      <p className="text-xs font-medium uppercase tracking-wide text-slate-400">{label}</p>
      <p className={`mt-2 text-2xl font-bold ${accent}`}>
        {value}
        <span className="ml-1 text-base font-medium text-slate-400">{suffix}</span>
      </p>
    </div>
  );
}
