import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Design decision: the dev server proxies /api to the backend container so
// the frontend can always call same-origin relative paths ("/api/v1/...")
// in both local dev and behind an Nginx reverse proxy in production,
// avoiding hardcoded absolute URLs / CORS friction across environments.
export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 5173,
    proxy: {
      "/api": {
        target: process.env.VITE_API_PROXY_TARGET || "http://localhost:8000",
        changeOrigin: true,
      },
    },
  },
});
