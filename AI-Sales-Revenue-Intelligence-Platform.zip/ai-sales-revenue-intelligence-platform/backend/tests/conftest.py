"""
Shared pytest fixtures.

Design decision
----------------
Tests run against an in-memory SQLite database rather than PostgreSQL.
This trades a small amount of SQL-dialect fidelity (e.g. no native
`ON CONFLICT ... DO UPDATE` postgres-specific syntax in the ETL tests,
which is why the ETL upsert path is tested separately via its pure
Pandas transform function) for tests that run in milliseconds with zero
external dependencies -- essential for a fast CI pipeline. The FastAPI
`app.dependency_overrides` mechanism swaps the real `get_db` dependency
for a session bound to this SQLite engine, so route/service code under
test is completely unaware it isn't talking to Postgres.
"""
from datetime import date, timedelta

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.db.base_class import Base
from app.db.session import get_db
from app.main import app
from app.models.hotel import Hotel, RoomType
from app.models.revenue import RevenueRecord
from app.models.user import User, UserRole
from app.core.security import get_password_hash

TEST_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture(scope="function", autouse=True)
def _reset_db():
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture()
def db_session():
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()


@pytest.fixture()
def client(db_session):
    def _override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = _override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


@pytest.fixture()
def admin_user(db_session):
    user = User(
        email="admin@test.com",
        full_name="Test Admin",
        hashed_password=get_password_hash("Password123"),
        role=UserRole.ADMIN,
        is_active=True,
    )
    db_session.add(user)
    db_session.commit()
    db_session.refresh(user)
    return user


@pytest.fixture()
def auth_headers(client, admin_user):
    response = client.post(
        "/api/v1/auth/login",
        data={"username": admin_user.email, "password": "Password123"},
    )
    token = response.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture()
def sample_hotel_with_revenue(db_session):
    hotel = Hotel(name="Test Hotel", city="Testville", country="Testland", star_rating=4, total_rooms=100)
    db_session.add(hotel)
    db_session.flush()
    db_session.add(RoomType(hotel_id=hotel.id, name="Standard", base_price=100, max_occupancy=2))

    start = date.today() - timedelta(days=30)
    for i in range(30):
        db_session.add(
            RevenueRecord(
                hotel_id=hotel.id,
                date=start + timedelta(days=i),
                room_revenue=1000 + i * 10,
                fnb_revenue=200,
                other_revenue=50,
                total_revenue=1250 + i * 10,
                rooms_sold=50 + i,
                occupancy_rate=50 + i,
                adr=100,
                revpar=50,
            )
        )
    db_session.commit()
    db_session.refresh(hotel)
    return hotel
