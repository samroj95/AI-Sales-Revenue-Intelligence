import pandas as pd

from app.ml.feature_engineering import (
    compute_adr,
    compute_booking_lead_time,
    compute_cancellation_rate,
    compute_customer_lifetime_value,
    compute_occupancy_rate,
    compute_repeat_customer_pct,
    compute_revpar,
)


def test_compute_adr():
    room_revenue = pd.Series([1000, 0, 500])
    rooms_sold = pd.Series([10, 0, 5])
    result = compute_adr(room_revenue, rooms_sold)
    assert result.tolist() == [100.0, 0.0, 100.0]


def test_compute_revpar():
    room_revenue = pd.Series([1000, 2000])
    result = compute_revpar(room_revenue, total_rooms=100)
    assert result.tolist() == [10.0, 20.0]


def test_compute_occupancy_rate():
    rooms_sold = pd.Series([50, 100])
    result = compute_occupancy_rate(rooms_sold, total_rooms=100)
    assert result.tolist() == [50.0, 100.0]


def test_compute_booking_lead_time():
    booking_date = pd.Series(["2024-01-01", "2024-01-10"])
    check_in = pd.Series(["2024-01-05", "2024-01-10"])
    result = compute_booking_lead_time(booking_date, check_in)
    assert result.tolist() == [4, 0]


def test_compute_cancellation_rate():
    status = pd.Series(["confirmed", "cancelled", "cancelled", "checked_out"])
    assert compute_cancellation_rate(status) == 50.0


def test_compute_customer_lifetime_value_and_repeat_pct():
    df = pd.DataFrame(
        {
            "customer_id": [1, 1, 2, 3, 3, 3],
            "total_amount": [100, 150, 200, 50, 60, 70],
            "status": ["checked_out", "checked_out", "checked_out", "cancelled", "checked_out", "checked_out"],
        }
    )
    features = compute_customer_lifetime_value(df)
    customer_1 = features[features["customer_id"] == 1].iloc[0]
    assert customer_1["lifetime_value"] == 250
    assert customer_1["total_stays"] == 2
    assert customer_1["is_repeat_customer"] is True or bool(customer_1["is_repeat_customer"]) is True

    customer_2 = features[features["customer_id"] == 2].iloc[0]
    assert bool(customer_2["is_repeat_customer"]) is False

    repeat_pct = compute_repeat_customer_pct(features)
    assert 0 <= repeat_pct <= 100
