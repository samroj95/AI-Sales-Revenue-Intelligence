def test_login_success(client, admin_user):
    response = client.post(
        "/api/v1/auth/login",
        data={"username": admin_user.email, "password": "Password123"},
    )
    assert response.status_code == 200
    body = response.json()
    assert "access_token" in body
    assert "refresh_token" in body
    assert body["token_type"] == "bearer"


def test_login_wrong_password(client, admin_user):
    response = client.post(
        "/api/v1/auth/login",
        data={"username": admin_user.email, "password": "WrongPassword"},
    )
    assert response.status_code == 401


def test_read_current_user(client, auth_headers):
    response = client.get("/api/v1/auth/me", headers=auth_headers)
    assert response.status_code == 200
    assert response.json()["email"] == "admin@test.com"
    assert response.json()["role"] == "admin"


def test_unauthenticated_request_rejected(client):
    response = client.get("/api/v1/auth/me")
    assert response.status_code == 401


def test_register_requires_admin_role(client, db_session):
    from app.core.security import get_password_hash
    from app.models.user import User, UserRole

    analyst = User(
        email="analyst@test.com",
        full_name="Analyst",
        hashed_password=get_password_hash("Password123"),
        role=UserRole.REVENUE_MANAGER,
    )
    db_session.add(analyst)
    db_session.commit()

    login = client.post(
        "/api/v1/auth/login", data={"username": "analyst@test.com", "password": "Password123"}
    )
    token = login.json()["access_token"]

    response = client.post(
        "/api/v1/auth/register",
        json={
            "email": "new@test.com",
            "full_name": "New User",
            "password": "Password123",
            "role": "analyst",
        },
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 403
