from datetime import date, timedelta

from app.ml.forecasting_service import ForecastingService


def _make_history(days: int, base: float = 1000.0, weekly_amplitude: float = 150.0) -> list[dict]:
    start = date.today() - timedelta(days=days)
    history = []
    for i in range(days):
        d = start + timedelta(days=i)
        seasonal = weekly_amplitude if d.weekday() in (4, 5) else 0
        history.append({"date": d, "total_revenue": base + seasonal + (i * 2)})
    return history


def test_insufficient_data_returns_empty_forecast():
    service = ForecastingService()
    method, points = service.forecast(_make_history(3), horizon_days=7)
    assert method == "insufficient_data"
    assert points == []


def test_fallback_forecast_for_short_series():
    service = ForecastingService()
    method, points = service.forecast(_make_history(10), horizon_days=5)
    assert method == "weighted_moving_average_trend"
    assert len(points) == 5
    assert all(p["forecast_revenue"] >= 0 for p in points)
    assert all(p["lower_bound"] <= p["forecast_revenue"] <= p["upper_bound"] for p in points)


def test_seasonal_forecast_for_long_series():
    service = ForecastingService()
    method, points = service.forecast(_make_history(60), horizon_days=14)
    assert method == "holt_winters_seasonal"
    assert len(points) == 14
    # Forecast should roughly track the upward trend in the synthetic data.
    assert points[-1]["forecast_revenue"] > points[0]["forecast_revenue"] * 0.5
