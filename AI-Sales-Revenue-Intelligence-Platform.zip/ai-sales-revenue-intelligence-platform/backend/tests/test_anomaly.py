from datetime import date, timedelta

from app.ml.anomaly_service import AnomalyDetectionService


def _history_with_spike(days: int = 40, spike_index: int = 30) -> list[dict]:
    start = date.today() - timedelta(days=days)
    history = []
    for i in range(days):
        revenue = 1000.0
        occupancy = 60.0
        adr = 100.0
        if i == spike_index:
            revenue = 8000.0  # deliberate outlier
            occupancy = 95.0
        history.append(
            {
                "date": start + timedelta(days=i),
                "total_revenue": revenue,
                "occupancy_rate": occupancy,
                "adr": adr,
            }
        )
    return history


def test_zscore_detects_injected_spike():
    service = AnomalyDetectionService()
    count, points = service.detect(_history_with_spike(), method="zscore")
    assert count >= 1
    spike_point = points[30]
    assert spike_point["is_anomaly"] is True
    assert spike_point["severity"] in ("moderate", "severe")


def test_zscore_no_false_positive_on_flat_series():
    service = AnomalyDetectionService()
    flat_history = [
        {"date": date.today() - timedelta(days=i), "total_revenue": 1000.0,
         "occupancy_rate": 60.0, "adr": 100.0}
        for i in range(20)
    ]
    count, _ = service.detect(flat_history, method="zscore")
    assert count == 0


def test_isolation_forest_runs_and_returns_points():
    service = AnomalyDetectionService()
    count, points = service.detect(_history_with_spike(), method="isolation_forest")
    assert len(points) == 40
    assert count >= 1
