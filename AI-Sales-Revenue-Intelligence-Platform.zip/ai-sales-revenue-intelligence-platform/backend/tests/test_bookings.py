from datetime import date, timedelta


def _make_booking_payload(hotel_id: int, room_type_id: int) -> dict:
    today = date.today()
    return {
        "hotel_id": hotel_id,
        "room_type_id": room_type_id,
        "customer_name": "Jane Doe",
        "channel": "direct",
        "booking_date": str(today - timedelta(days=2)),
        "check_in": str(today),
        "check_out": str(today + timedelta(days=2)),
        "nights": 2,
        "num_guests": 2,
        "total_amount": 300.0,
        "discount_amount": 0,
    }


def test_create_and_get_booking(client, auth_headers, sample_hotel_with_revenue, db_session):
    from app.models.hotel import RoomType

    room_type = db_session.query(RoomType).filter_by(hotel_id=sample_hotel_with_revenue.id).first()
    payload = _make_booking_payload(sample_hotel_with_revenue.id, room_type.id)

    create_resp = client.post("/api/v1/bookings", json=payload, headers=auth_headers)
    assert create_resp.status_code == 201
    booking_id = create_resp.json()["id"]

    get_resp = client.get(f"/api/v1/bookings/{booking_id}", headers=auth_headers)
    assert get_resp.status_code == 200
    assert get_resp.json()["customer_name"] == "Jane Doe"


def test_list_bookings_pagination(client, auth_headers, sample_hotel_with_revenue, db_session):
    from app.models.hotel import RoomType

    room_type = db_session.query(RoomType).filter_by(hotel_id=sample_hotel_with_revenue.id).first()
    for _ in range(3):
        client.post(
            "/api/v1/bookings",
            json=_make_booking_payload(sample_hotel_with_revenue.id, room_type.id),
            headers=auth_headers,
        )

    resp = client.get(
        f"/api/v1/bookings?hotel_id={sample_hotel_with_revenue.id}&page=1&page_size=2",
        headers=auth_headers,
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["total"] == 3
    assert len(body["items"]) == 2


def test_get_nonexistent_booking_returns_404(client, auth_headers):
    resp = client.get("/api/v1/bookings/999999", headers=auth_headers)
    assert resp.status_code == 404
