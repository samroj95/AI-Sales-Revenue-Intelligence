import numpy as np
import pandas as pd

from app.etl.data_cleaning import (
    detect_outliers_iqr,
    parse_currency,
    remove_duplicates,
    standardize_country,
)


def test_parse_currency_variants():
    assert parse_currency("$150") == 150.0
    assert parse_currency("150 USD") == 150.0
    assert parse_currency("USD 150") == 150.0
    assert parse_currency("1,250.50") == 1250.50
    assert parse_currency(150) == 150.0
    assert np.isnan(parse_currency(None))
    assert np.isnan(parse_currency("not a number"))


def test_standardize_country_aliases():
    assert standardize_country("usa") == "United States"
    assert standardize_country("U.S.A.") == "United States"
    assert standardize_country("uk") == "United Kingdom"
    assert standardize_country("france") == "France"
    assert standardize_country(None) == "Unknown"


def test_remove_duplicates():
    df = pd.DataFrame({"a": [1, 1, 2], "b": ["x", "x", "y"]})
    result = remove_duplicates(df, subset=["a", "b"])
    assert len(result) == 2


def test_detect_outliers_iqr():
    series = pd.Series([10, 12, 11, 13, 12, 500])  # 500 is a clear outlier
    mask = detect_outliers_iqr(series)
    assert mask.iloc[-1] == True  # noqa: E712
    assert mask.iloc[:-1].sum() == 0
