from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.session import get_db
from app.models.booking import Booking
from app.models.hotel import Hotel
from app.models.revenue import RevenueRecord
from app.models.user import User

router = APIRouter(prefix="/dashboard", tags=["Executive Dashboard"])


class ChannelMix(BaseModel):
    channel: str
    booking_count: int
    total_revenue: float


class HotelPerformance(BaseModel):
    hotel_id: int
    hotel_name: str
    city: str
    total_revenue: float
    avg_revpar: float


@router.get("/channel-mix", response_model=list[ChannelMix])
def channel_mix(
    hotel_id: int | None = None,
    db: Session = Depends(get_db),
    _current_user: User = Depends(get_current_user),
):
    """Revenue and booking-count breakdown by acquisition channel (OTA, direct, etc.)."""
    stmt = select(
        Booking.channel,
        func.count(Booking.id),
        func.coalesce(func.sum(Booking.total_amount), 0),
    ).group_by(Booking.channel)
    if hotel_id is not None:
        stmt = stmt.where(Booking.hotel_id == hotel_id)

    rows = db.execute(stmt).all()
    return [
        ChannelMix(channel=channel.value, booking_count=count, total_revenue=float(total))
        for channel, count, total in rows
    ]


@router.get("/top-hotels", response_model=list[HotelPerformance])
def top_hotels(
    limit: int = 5,
    db: Session = Depends(get_db),
    _current_user: User = Depends(get_current_user),
):
    """Portfolio leaderboard by total revenue -- powers the executive summary widget."""
    stmt = (
        select(
            Hotel.id,
            Hotel.name,
            Hotel.city,
            func.coalesce(func.sum(RevenueRecord.total_revenue), 0),
            func.coalesce(func.avg(RevenueRecord.revpar), 0),
        )
        .join(RevenueRecord, RevenueRecord.hotel_id == Hotel.id, isouter=True)
        .group_by(Hotel.id, Hotel.name, Hotel.city)
        .order_by(func.coalesce(func.sum(RevenueRecord.total_revenue), 0).desc())
        .limit(limit)
    )
    rows = db.execute(stmt).all()
    return [
        HotelPerformance(
            hotel_id=hid,
            hotel_name=name,
            city=city,
            total_revenue=float(total_rev),
            avg_revpar=round(float(avg_revpar), 2),
        )
        for hid, name, city, total_rev, avg_revpar in rows
    ]
