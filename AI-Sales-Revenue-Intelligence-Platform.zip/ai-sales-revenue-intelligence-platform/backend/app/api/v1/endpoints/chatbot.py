from fastapi import APIRouter, Depends, HTTPException, status
from loguru import logger
from sqlalchemy.orm import Session

from app.ai.rag_service import RagChatService
from app.api.deps import get_current_user
from app.db.session import get_db
from app.models.user import User
from app.schemas.chatbot import ChatRequest, ChatResponse

router = APIRouter(prefix="/chatbot", tags=["AI Chatbot (RAG)"])


@router.post("/query", response_model=ChatResponse)
def query_chatbot(
    request: ChatRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    try:
        service = RagChatService(db)
        result = service.answer(request.message, hotel_id=request.hotel_id)
        return ChatResponse(**result)
    except Exception as exc:  # noqa: BLE001
        logger.exception("Chatbot query failed for user_id={}", current_user.id)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"AI assistant is temporarily unavailable: {exc}",
        ) from exc
