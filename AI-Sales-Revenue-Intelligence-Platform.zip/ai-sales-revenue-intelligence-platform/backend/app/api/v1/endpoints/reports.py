"""
Report export endpoint (Module 9: /download-report).

Design decision
----------------
Executives and Finance (per the 5-role auth model) frequently need to
take a KPI snapshot out of the platform and into an email or board deck.
Rather than a PDF (harder to keep lightweight without a heavy rendering
dependency), we generate an .xlsx workbook via Pandas' `ExcelWriter`
(openpyxl backend) with one sheet per relevant dataset -- Finance teams
overwhelmingly prefer Excel for further pivoting anyway. The file is
streamed back with `StreamingResponse` rather than written to disk on
the server, so nothing lingers that would need cleanup or could leak
data across requests.
"""
from datetime import date
from io import BytesIO

import pandas as pd
from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.session import get_db
from app.models.user import User
from app.repositories.booking_repository import BookingRepository
from app.repositories.revenue_repository import RevenueRepository

router = APIRouter(tags=["Reports"])


@router.get("/download-report")
def download_report(
    hotel_id: int,
    start_date: date | None = None,
    end_date: date | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    revenue_repo = RevenueRepository(db)
    booking_repo = BookingRepository(db)

    timeseries = revenue_repo.get_time_series(hotel_id, start_date, end_date)
    kpis = revenue_repo.kpi_summary(hotel_id, start_date, end_date)
    bookings, total_bookings = booking_repo.list(
        hotel_id=hotel_id, start_date=start_date, end_date=end_date, page=1, page_size=1000
    )

    kpi_df = pd.DataFrame(
        [
            {
                "Total Revenue": kpis["total_revenue"],
                "Avg Occupancy %": kpis["avg_occupancy_rate"],
                "Avg ADR": kpis["avg_adr"],
                "Avg RevPAR": kpis["avg_revpar"],
                "Cancellation Rate %": booking_repo.cancellation_rate(hotel_id),
                "Total Bookings": total_bookings,
                "Period Start": kpis["period_start"],
                "Period End": kpis["period_end"],
            }
        ]
    )
    revenue_df = pd.DataFrame(
        [
            {
                "Date": r.date,
                "Total Revenue": float(r.total_revenue),
                "Occupancy %": float(r.occupancy_rate),
                "ADR": float(r.adr),
                "RevPAR": float(r.revpar),
            }
            for r in timeseries
        ]
    )
    bookings_df = pd.DataFrame(
        [
            {
                "Guest": b.customer_name,
                "Channel": b.channel.value,
                "Check-in": b.check_in,
                "Nights": b.nights,
                "Amount": float(b.total_amount),
                "Status": b.status.value,
            }
            for b in bookings
        ]
    )

    buffer = BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        kpi_df.to_excel(writer, sheet_name="KPI Summary", index=False)
        revenue_df.to_excel(writer, sheet_name="Daily Revenue", index=False)
        bookings_df.to_excel(writer, sheet_name="Bookings", index=False)
    buffer.seek(0)

    filename = f"hotel_{hotel_id}_revenue_report_{date.today().isoformat()}.xlsx"
    return StreamingResponse(
        buffer,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )
