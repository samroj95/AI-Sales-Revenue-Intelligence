from fastapi import APIRouter, Depends
from pydantic import BaseModel, ConfigDict
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.session import get_db
from app.models.hotel import Hotel
from app.models.user import User

router = APIRouter(prefix="/hotels", tags=["Hotels"])


class HotelRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    city: str
    country: str
    star_rating: int
    total_rooms: int


@router.get("", response_model=list[HotelRead])
def list_hotels(db: Session = Depends(get_db), _current_user: User = Depends(get_current_user)):
    return list(db.scalars(select(Hotel).order_by(Hotel.name)).all())
