from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.session import get_db
from app.ml.forecast_comparison_service import ForecastComparisonService
from app.ml.forecasting_service import ForecastingService
from app.models.user import User
from app.repositories.revenue_repository import RevenueRepository
from app.schemas.revenue import ForecastComparisonResponse, ForecastResponse

router = APIRouter(prefix="/forecast", tags=["Forecasting"])
_service = ForecastingService()
_comparison_service = ForecastComparisonService()


@router.get("/{hotel_id}", response_model=ForecastResponse)
def forecast_revenue(
    hotel_id: int,
    horizon_days: int = Query(default=14, ge=1, le=90),
    db: Session = Depends(get_db),
    _current_user: User = Depends(get_current_user),
):
    history_records = RevenueRepository(db).get_time_series(hotel_id)
    if not history_records:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No revenue history found for this hotel.",
        )

    history_dicts = [
        {"date": r.date, "total_revenue": float(r.total_revenue)} for r in history_records
    ]
    method, forecast_points = _service.forecast(history_dicts, horizon_days)

    if method == "insufficient_data":
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="At least 5 days of revenue history are required to forecast.",
        )

    return ForecastResponse(
        hotel_id=hotel_id,
        method=method,
        horizon_days=horizon_days,
        history=history_records,
        forecast=forecast_points,
    )


@router.get("/{hotel_id}/compare", response_model=ForecastComparisonResponse)
def compare_forecast_models(
    hotel_id: int,
    horizon_days: int = Query(default=14, ge=1, le=90),
    db: Session = Depends(get_db),
    _current_user: User = Depends(get_current_user),
):
    """
    Module 5 - Forecasting ensemble.

    Backtests Holt-Winters, Prophet, ARIMA (SARIMAX), and XGBoost against
    the most recent 7 days of actuals, scores each with MAPE/RMSE, and
    returns forward-looking forecasts from every model that trained
    successfully plus a `recommended_model` pick.
    """
    history_records = RevenueRepository(db).get_time_series(hotel_id)
    if not history_records:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No revenue history found for this hotel.",
        )

    history_dicts = [
        {"date": r.date, "total_revenue": float(r.total_revenue)} for r in history_records
    ]
    result = _comparison_service.backtest_and_forecast(history_dicts, horizon_days)

    return ForecastComparisonResponse(
        hotel_id=hotel_id,
        horizon_days=horizon_days,
        recommended_model=result["recommended_model"],
        backtest_scores=result["backtest_scores"],
        forecasts=result["forecasts"],
    )
