from typing import Literal

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status

from app.api.deps import require_roles
from app.db.session import get_db
from app.etl.ingestion_service import DATASET_DISPATCH
from app.models.user import UserRole
from sqlalchemy.orm import Session

router = APIRouter(tags=["Data Ingestion"])

DatasetType = Literal["bookings", "customers", "restaurant", "spa", "reviews", "employees"]


@router.post(
    "/upload-data",
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(require_roles(UserRole.ADMIN, UserRole.REVENUE_MANAGER))],
)
async def upload_data(
    dataset_type: DatasetType = Query(..., description="Which source system this CSV represents."),
    hotel_id: int | None = Query(default=None, description="Required for hotel-scoped datasets."),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """
    Module 1 - Data Ingestion.

    Accepts Booking.csv / Customer.csv / Revenue.csv / Restaurant.csv /
    Employee.csv style exports, runs them through Module 2 (cleaning) and
    Module 3 (feature engineering), and loads them into PostgreSQL.
    """
    if not file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Only .csv files are supported.")

    if dataset_type != "customers" and hotel_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"hotel_id is required for dataset_type='{dataset_type}'.",
        )

    file_bytes = await file.read()
    ingest_fn = DATASET_DISPATCH[dataset_type]

    try:
        if dataset_type == "customers":
            result = ingest_fn(db, file_bytes)
        else:
            result = ingest_fn(db, file_bytes, hotel_id)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Failed to ingest {dataset_type} CSV: {exc}",
        ) from exc

    return result.as_dict()
