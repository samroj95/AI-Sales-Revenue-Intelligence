from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.alerts.alert_service import run_alert_checks
from app.api.deps import get_current_user
from app.db.session import get_db
from app.models.user import User

router = APIRouter(prefix="/alerts", tags=["Alerts"])


@router.get("/check/{hotel_id}")
def check_alerts(
    hotel_id: int,
    db: Session = Depends(get_db),
    _current_user: User = Depends(get_current_user),
):
    """
    Module 8 - Alerts. Evaluates revenue-drop, low-occupancy, and
    high-cancellation rules for the given hotel and dispatches any that
    fire to their respective channel (email / Slack / AI recommendation).
    In production this would also run on a schedule (see docs/DEPLOYMENT.md
    for the recommended cron/EventBridge setup) rather than only on demand.
    """
    fired = run_alert_checks(db, hotel_id)
    return {"hotel_id": hotel_id, "alerts_fired": len(fired), "alerts": fired}
