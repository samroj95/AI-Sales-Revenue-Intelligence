from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.session import get_db
from app.ml.anomaly_service import AnomalyDetectionService
from app.models.user import User
from app.repositories.revenue_repository import RevenueRepository
from app.schemas.revenue import AnomalyResponse

router = APIRouter(prefix="/anomaly", tags=["Anomaly Detection"])
_service = AnomalyDetectionService()


@router.get("/{hotel_id}", response_model=AnomalyResponse)
def detect_anomalies(
    hotel_id: int,
    method: Literal["zscore", "isolation_forest"] = Query(default="zscore"),
    db: Session = Depends(get_db),
    _current_user: User = Depends(get_current_user),
):
    history_records = RevenueRepository(db).get_time_series(hotel_id)
    if not history_records:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No revenue history found for this hotel.",
        )

    history_dicts = [
        {
            "date": r.date,
            "total_revenue": float(r.total_revenue),
            "occupancy_rate": float(r.occupancy_rate),
            "adr": float(r.adr),
        }
        for r in history_records
    ]
    count, points = _service.detect(history_dicts, method=method)

    return AnomalyResponse(
        hotel_id=hotel_id, method=method, anomalies_detected=count, points=points
    )
