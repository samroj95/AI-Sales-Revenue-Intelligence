from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_roles
from app.db.session import get_db
from app.models.user import User, UserRole
from app.repositories.booking_repository import BookingRepository
from app.schemas.booking import BookingCreate, BookingListResponse, BookingRead

router = APIRouter(prefix="/bookings", tags=["Bookings"])


@router.post(
    "",
    response_model=BookingRead,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(require_roles(UserRole.ADMIN, UserRole.REVENUE_MANAGER, UserRole.GENERAL_MANAGER))],
)
def create_booking(booking_in: BookingCreate, db: Session = Depends(get_db)):
    return BookingRepository(db).create(booking_in)


@router.get("", response_model=BookingListResponse)
def list_bookings(
    hotel_id: int | None = None,
    channel: str | None = None,
    status_filter: str | None = Query(default=None, alias="status"),
    start_date: date | None = None,
    end_date: date | None = None,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=25, ge=1, le=200),
    db: Session = Depends(get_db),
    _current_user: User = Depends(get_current_user),
):
    items, total = BookingRepository(db).list(
        hotel_id=hotel_id,
        channel=channel,
        status=status_filter,
        start_date=start_date,
        end_date=end_date,
        page=page,
        page_size=page_size,
    )
    return BookingListResponse(total=total, page=page, page_size=page_size, items=items)


@router.get("/{booking_id}", response_model=BookingRead)
def get_booking(
    booking_id: int, db: Session = Depends(get_db), _current_user: User = Depends(get_current_user)
):
    booking = BookingRepository(db).get(booking_id)
    if booking is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Booking not found")
    return booking
