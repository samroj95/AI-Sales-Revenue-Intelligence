"""
Thin alias routes matching the platform spec's originally-sketched API
surface (`/get-dashboard`, `/get-revenue`, `/get-forecast`, `/get-kpi`,
`/chat`). Each delegates to the canonical, more RESTful endpoint
(`/dashboard/*`, `/revenue/*`, `/forecast/*`, `/chatbot/query`) so there
is exactly one implementation of each behavior -- these routes exist
purely for interface compatibility with the original design doc/demo
scripts, not as a second code path to maintain.
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.ai.rag_service import RagChatService
from app.api.deps import get_current_user
from app.db.session import get_db
from app.models.user import User
from app.ml.forecasting_service import ForecastingService
from app.repositories.booking_repository import BookingRepository
from app.repositories.revenue_repository import RevenueRepository
from app.schemas.chatbot import ChatRequest, ChatResponse

router = APIRouter(tags=["Spec-Compatible Aliases"])
_forecast_service = ForecastingService()


@router.get("/get-kpi")
def get_kpi(
    hotel_id: int | None = None,
    db: Session = Depends(get_db),
    _current_user: User = Depends(get_current_user),
):
    """Alias for GET /revenue/kpis."""
    summary = RevenueRepository(db).kpi_summary(hotel_id, None, None)
    summary["cancellation_rate"] = BookingRepository(db).cancellation_rate(hotel_id)
    return summary


@router.get("/get-revenue")
def get_revenue(
    hotel_id: int,
    db: Session = Depends(get_db),
    _current_user: User = Depends(get_current_user),
):
    """Alias for GET /revenue/{hotel_id}/timeseries."""
    return RevenueRepository(db).get_time_series(hotel_id)


@router.get("/get-forecast")
def get_forecast(
    hotel_id: int,
    horizon_days: int = 14,
    db: Session = Depends(get_db),
    _current_user: User = Depends(get_current_user),
):
    """Alias for GET /forecast/{hotel_id} (single-model quick forecast)."""
    history = RevenueRepository(db).get_time_series(hotel_id)
    history_dicts = [{"date": r.date, "total_revenue": float(r.total_revenue)} for r in history]
    method, points = _forecast_service.forecast(history_dicts, horizon_days)
    return {"hotel_id": hotel_id, "method": method, "forecast": points}


@router.get("/get-dashboard")
def get_dashboard_bundle(
    hotel_id: int,
    db: Session = Depends(get_db),
    _current_user: User = Depends(get_current_user),
):
    """
    Convenience 'everything the Executive Overview page needs in one
    call' bundle -- reduces round-trips for lightweight/mobile clients.
    """
    kpis = RevenueRepository(db).kpi_summary(hotel_id, None, None)
    kpis["cancellation_rate"] = BookingRepository(db).cancellation_rate(hotel_id)
    revenue_series = RevenueRepository(db).get_time_series(hotel_id)
    return {"hotel_id": hotel_id, "kpis": kpis, "revenue_timeseries": revenue_series}


@router.post("/chat", response_model=ChatResponse)
def chat(
    request: ChatRequest,
    db: Session = Depends(get_db),
    _current_user: User = Depends(get_current_user),
):
    """Alias for POST /chatbot/query."""
    result = RagChatService(db).answer(request.message, hotel_id=request.hotel_id)
    return ChatResponse(**result)
