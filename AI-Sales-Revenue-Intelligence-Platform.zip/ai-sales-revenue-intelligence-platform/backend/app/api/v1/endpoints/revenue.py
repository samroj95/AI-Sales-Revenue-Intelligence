from datetime import date

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.session import get_db
from app.models.user import User
from app.repositories.booking_repository import BookingRepository
from app.repositories.revenue_repository import RevenueRepository
from app.schemas.revenue import KpiSummary, RevenueRecordRead

router = APIRouter(prefix="/revenue", tags=["Revenue & KPIs"])


@router.get("/{hotel_id}/timeseries", response_model=list[RevenueRecordRead])
def get_revenue_timeseries(
    hotel_id: int,
    start_date: date | None = None,
    end_date: date | None = None,
    db: Session = Depends(get_db),
    _current_user: User = Depends(get_current_user),
):
    return RevenueRepository(db).get_time_series(hotel_id, start_date, end_date)


@router.get("/kpis", response_model=KpiSummary)
def get_kpi_summary(
    hotel_id: int | None = None,
    start_date: date | None = None,
    end_date: date | None = None,
    db: Session = Depends(get_db),
    _current_user: User = Depends(get_current_user),
):
    """
    Aggregated KPIs (total revenue, occupancy, ADR, RevPAR, cancellation
    rate) powering the executive dashboard. This is also the exact query
    shape a Power BI DirectQuery / import dataset would call.
    """
    rev_summary = RevenueRepository(db).kpi_summary(hotel_id, start_date, end_date)
    booking_repo = BookingRepository(db)
    _, total_bookings = booking_repo.list(hotel_id=hotel_id, page=1, page_size=1)
    cancellation_rate = booking_repo.cancellation_rate(hotel_id)

    return KpiSummary(
        total_revenue=rev_summary["total_revenue"],
        avg_occupancy_rate=rev_summary["avg_occupancy_rate"],
        avg_adr=rev_summary["avg_adr"],
        avg_revpar=rev_summary["avg_revpar"],
        total_bookings=total_bookings,
        cancellation_rate=cancellation_rate,
        period_start=rev_summary["period_start"] or date.today(),
        period_end=rev_summary["period_end"] or date.today(),
    )
