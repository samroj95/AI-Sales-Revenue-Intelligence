from fastapi import APIRouter

from app.api.v1.endpoints import (
    alerts,
    anomaly,
    auth,
    bookings,
    chatbot,
    dashboard,
    forecasting,
    hotels,
    ingestion,
    reports,
    revenue,
)
from app.api.v1.endpoints import spec_aliases

api_router = APIRouter()
api_router.include_router(auth.router)
api_router.include_router(ingestion.router)
api_router.include_router(hotels.router)
api_router.include_router(bookings.router)
api_router.include_router(revenue.router)
api_router.include_router(forecasting.router)
api_router.include_router(anomaly.router)
api_router.include_router(chatbot.router)
api_router.include_router(dashboard.router)
api_router.include_router(alerts.router)
api_router.include_router(reports.router)
api_router.include_router(spec_aliases.router)
