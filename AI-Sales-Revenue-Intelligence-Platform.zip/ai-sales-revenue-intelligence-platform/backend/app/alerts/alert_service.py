"""
Alert engine (Module 8).

Design decision
----------------
Three independent rules, each mapped to the channel and remediation the
spec calls for:

  * Revenue drop beyond threshold (vs. the trailing 7-day baseline)  -> email,
    since finance/ownership want a written record they can act on later.
  * Occupancy below threshold                                       -> Slack,
    since the on-property team needs to see and react same-day.
  * Cancellation rate above threshold                                -> an
    AI-generated recommendation (via the existing LLM provider) rather
    than a static message, since the right response genuinely depends
    on context (channel mix, season, competitor activity) that a fixed
    template can't capture well.

Each rule is a pure "evaluate -> dict-or-None" function, and the public
`run_alert_checks` orchestrator (Strategy/Chain-of-Responsibility-ish)
just calls each in turn and collects what fired -- easy to unit test
each rule with synthetic data, and easy to add a 4th rule later without
touching the other three.
"""
from datetime import date, timedelta

from loguru import logger
from sqlalchemy.orm import Session

from app.ai.llm_provider import get_chat_model
from app.alerts.notifiers import send_email_alert, send_slack_alert
from app.core.config import settings
from app.repositories.booking_repository import BookingRepository
from app.repositories.revenue_repository import RevenueRepository


def check_revenue_drop(db: Session, hotel_id: int) -> dict | None:
    repo = RevenueRepository(db)
    today = date.today()
    recent = repo.get_time_series(hotel_id, today - timedelta(days=14), today)
    if len(recent) < 8:
        return None

    last_7 = [float(r.total_revenue) for r in recent[-7:]]
    prior_7 = [float(r.total_revenue) for r in recent[-14:-7]]
    if not prior_7 or sum(prior_7) == 0:
        return None

    drop_pct = round(100 * (sum(prior_7) - sum(last_7)) / sum(prior_7), 2)
    if drop_pct < settings.REVENUE_DROP_THRESHOLD_PCT:
        return None

    subject = f"[Revenue Alert] Hotel {hotel_id} revenue down {drop_pct}% week-over-week"
    body = (
        f"Total revenue for hotel_id={hotel_id} fell {drop_pct}% in the last 7 days "
        f"(${sum(last_7):,.2f}) compared to the prior 7 days (${sum(prior_7):,.2f}).\n"
        f"Threshold: {settings.REVENUE_DROP_THRESHOLD_PCT}%."
    )
    send_email_alert(subject, body)
    return {"rule": "revenue_drop", "channel": "email", "drop_pct": drop_pct, "message": subject}


def check_low_occupancy(db: Session, hotel_id: int) -> dict | None:
    repo = RevenueRepository(db)
    today = date.today()
    recent = repo.get_time_series(hotel_id, today - timedelta(days=7), today)
    if not recent:
        return None

    avg_occupancy = sum(float(r.occupancy_rate) for r in recent) / len(recent)
    if avg_occupancy >= settings.OCCUPANCY_ALERT_THRESHOLD_PCT:
        return None

    text = (
        f":warning: *Low Occupancy Alert* -- hotel_id={hotel_id} averaged "
        f"{avg_occupancy:.1f}% occupancy over the last 7 days "
        f"(threshold: {settings.OCCUPANCY_ALERT_THRESHOLD_PCT}%)."
    )
    send_slack_alert(text)
    return {"rule": "low_occupancy", "channel": "slack", "avg_occupancy": round(avg_occupancy, 2), "message": text}


def check_high_cancellation(db: Session, hotel_id: int) -> dict | None:
    cancellation_rate = BookingRepository(db).cancellation_rate(hotel_id)
    if cancellation_rate < settings.CANCELLATION_ALERT_THRESHOLD_PCT:
        return None

    prompt = (
        "You are a hotel revenue-management advisor. The cancellation rate "
        f"for hotel_id={hotel_id} is currently {cancellation_rate}%, above the "
        f"{settings.CANCELLATION_ALERT_THRESHOLD_PCT}% alert threshold. In 3 short "
        "bullet points, recommend concrete, specific actions the revenue "
        "manager should consider this week."
    )
    try:
        chat_model = get_chat_model()
        response = chat_model.invoke(prompt)
        recommendation = response.content
    except Exception as exc:  # noqa: BLE001
        logger.error("AI recommendation generation failed: {}", exc)
        recommendation = (
            "AI recommendation unavailable. Suggested default actions: review "
            "cancellation policy strictness, audit overbooking allowance, and "
            "check for a competitor rate undercut."
        )

    return {
        "rule": "high_cancellation",
        "channel": "ai_recommendation",
        "cancellation_rate": cancellation_rate,
        "message": recommendation,
    }


def run_alert_checks(db: Session, hotel_id: int) -> list[dict]:
    checks = [check_revenue_drop, check_low_occupancy, check_high_cancellation]
    fired = []
    for check in checks:
        result = check(db, hotel_id)
        if result:
            fired.append(result)
    logger.info("Alert check for hotel_id={}: {} rule(s) fired.", hotel_id, len(fired))
    return fired
