"""
Alert delivery channels.

Design decision
----------------
Email and Slack are implemented as small, independent functions rather
than a single "notify()" god-function, so the alert engine
(alert_service.py) can route each condition to the channel that best
fits its urgency (Slack for a same-day occupancy dip the on-duty
manager should see immediately; email for a revenue-drop summary that
belongs in an inbox/audit trail). Both are wrapped in try/except and
log-don't-crash on failure -- a misconfigured SMTP server or an expired
Slack webhook must never take down the request that triggered the
alert check.
"""
import smtplib
from email.mime.text import MIMEText

import httpx
from loguru import logger

from app.core.config import settings


def send_email_alert(subject: str, body: str, to_address: str | None = None) -> bool:
    to_address = to_address or settings.ALERT_EMAIL_TO
    if not settings.SMTP_USER or not settings.SMTP_PASSWORD:
        logger.warning("SMTP not configured; skipping email alert: {}", subject)
        return False

    message = MIMEText(body)
    message["Subject"] = subject
    message["From"] = settings.ALERT_EMAIL_FROM
    message["To"] = to_address

    try:
        with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT) as server:
            server.starttls()
            server.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
            server.sendmail(settings.ALERT_EMAIL_FROM, [to_address], message.as_string())
        logger.info("Email alert sent: {}", subject)
        return True
    except Exception as exc:  # noqa: BLE001
        logger.error("Failed to send email alert '{}': {}", subject, exc)
        return False


def send_slack_alert(text: str) -> bool:
    if not settings.SLACK_WEBHOOK_URL:
        logger.warning("Slack webhook not configured; skipping Slack alert.")
        return False
    try:
        response = httpx.post(settings.SLACK_WEBHOOK_URL, json={"text": text}, timeout=5.0)
        response.raise_for_status()
        logger.info("Slack alert sent.")
        return True
    except Exception as exc:  # noqa: BLE001
        logger.error("Failed to send Slack alert: {}", exc)
        return False
