"""
Synthetic hospitality data generator.

Design decision
----------------
Real hotel booking data is never publishable (PII + commercially
sensitive), so we generate statistically realistic synthetic data
instead: weekend rate premiums, seasonal demand curves, channel mix
skewed toward OTAs (reflecting real industry distribution), and a small
number of deliberately injected anomalies (demand shocks, pricing
errors) so the anomaly-detection module has something genuine to find
end-to-end -- this makes the demo *provably* work rather than just
plotting a flat line.

This script is idempotent-by-intent: running it against an empty
database populates it; running it twice will create duplicate rows, so
it is meant to be run once per fresh environment (see README "Getting
Started").
"""
import random
from datetime import date, timedelta

import numpy as np
from faker import Faker
from loguru import logger
from sqlalchemy.orm import Session

from app.models.ancillary import RestaurantSale, SpaSale
from app.models.booking import Booking, BookingChannel, BookingStatus
from app.models.customer import Customer
from app.models.hotel import Hotel, RoomType
from app.models.revenue import RevenueRecord
from app.models.staff_and_reviews import (
    Department,
    Employee,
    Review,
    ReviewSentiment,
    ReviewSource,
)

fake = Faker()
random.seed(42)
np.random.seed(42)

HOTEL_SEED_DATA = [
    {"name": "Grand Meridian Downtown", "city": "New York", "country": "USA", "star_rating": 5, "total_rooms": 220},
    {"name": "Azure Bay Resort", "city": "Miami", "country": "USA", "star_rating": 5, "total_rooms": 180},
    {"name": "The Regency Suites", "city": "Chicago", "country": "USA", "star_rating": 4, "total_rooms": 150},
    {"name": "Lakeside Business Hotel", "city": "Toronto", "country": "Canada", "star_rating": 4, "total_rooms": 130},
    {"name": "Harborview Inn", "city": "Vancouver", "country": "Canada", "star_rating": 3, "total_rooms": 95},
]

ROOM_TYPE_TEMPLATES = [
    {"name": "Standard Queen", "base_price": 120, "max_occupancy": 2, "share": 0.40},
    {"name": "Deluxe King", "base_price": 165, "max_occupancy": 2, "share": 0.30},
    {"name": "Executive Suite", "base_price": 260, "max_occupancy": 3, "share": 0.20},
    {"name": "Presidential Suite", "base_price": 480, "max_occupancy": 4, "share": 0.10},
]

CHANNEL_WEIGHTS = {
    BookingChannel.OTA: 0.45,
    BookingChannel.DIRECT: 0.25,
    BookingChannel.CORPORATE: 0.15,
    BookingChannel.TRAVEL_AGENT: 0.10,
    BookingChannel.WALK_IN: 0.05,
}

HISTORY_DAYS = 365
CUSTOMER_POOL_SIZE = 800
LOYALTY_TIERS = ["none", "none", "silver", "silver", "gold", "platinum"]
REVIEW_SOURCES = list(ReviewSource)
DEPARTMENTS = list(Department)


def seed_customers(db: Session) -> list[Customer]:
    customers = []
    for _ in range(CUSTOMER_POOL_SIZE):
        is_loyalty = random.random() < 0.35
        customer = Customer(
            full_name=fake.name(),
            email=fake.unique.email(),
            country=fake.country(),
            is_loyalty_member=is_loyalty,
            loyalty_tier=random.choice(LOYALTY_TIERS) if is_loyalty else "none",
            join_date=fake.date_between(start_date="-3y", end_date="today") if is_loyalty else None,
        )
        db.add(customer)
        customers.append(customer)
    db.commit()
    for c in customers:
        db.refresh(c)
    logger.info("Seeded {} customers.", len(customers))
    return customers


def seed_hotels_and_room_types(db: Session) -> list[Hotel]:
    hotels = []
    for spec in HOTEL_SEED_DATA:
        hotel = Hotel(**spec)
        db.add(hotel)
        db.flush()  # get hotel.id without full commit
        for rt in ROOM_TYPE_TEMPLATES:
            db.add(
                RoomType(
                    hotel_id=hotel.id,
                    name=rt["name"],
                    base_price=rt["base_price"],
                    max_occupancy=rt["max_occupancy"],
                )
            )
        hotels.append(hotel)
    db.commit()
    logger.info("Seeded {} hotels with room types.", len(hotels))
    return hotels


def _seasonal_multiplier(day: date) -> float:
    """Peaks in summer (Jul/Aug) and December holidays; dips in Jan/Feb."""
    month_curve = {
        1: 0.75, 2: 0.78, 3: 0.90, 4: 0.95, 5: 1.00, 6: 1.10,
        7: 1.25, 8: 1.22, 9: 1.05, 10: 0.98, 11: 0.90, 12: 1.15,
    }
    return month_curve[day.month]


def _weekend_multiplier(day: date) -> float:
    return 1.20 if day.weekday() in (4, 5) else 1.0  # Fri/Sat premium


def generate_bookings_and_revenue(db: Session, hotels: list[Hotel], customers: list[Customer]) -> None:
    room_types_by_hotel = {
        hotel.id: db.query(RoomType).filter(RoomType.hotel_id == hotel.id).all()
        for hotel in hotels
    }
    start_date = date.today() - timedelta(days=HISTORY_DAYS)

    # A smaller "frequent guest" subset gets picked disproportionately often
    # so the customer base has genuine repeat-stay / CLV signal to analyze.
    frequent_guests = random.sample(customers, k=max(1, len(customers) // 5))

    # A handful of deliberate anomaly days per hotel so anomaly detection
    # has genuine signal to surface (demand shocks + a pricing error).
    anomaly_days = {
        hotel.id: set(
            random.sample(range(30, HISTORY_DAYS - 5), k=4)
        )
        for hotel in hotels
    }

    total_bookings = 0
    for hotel in hotels:
        base_occupancy_target = random.uniform(0.55, 0.72)
        for offset in range(HISTORY_DAYS):
            day = start_date + timedelta(days=offset)
            seasonal = _seasonal_multiplier(day)
            weekend = _weekend_multiplier(day)

            occupancy_target = min(0.98, base_occupancy_target * seasonal * weekend)

            anomaly_kind = None
            if offset in anomaly_days[hotel.id]:
                anomaly_kind = random.choice(["demand_spike", "demand_drop", "pricing_error"])
                if anomaly_kind == "demand_spike":
                    occupancy_target = min(0.99, occupancy_target * 1.6)
                elif anomaly_kind == "demand_drop":
                    occupancy_target = occupancy_target * 0.35

            rooms_sold_target = int(hotel.total_rooms * occupancy_target)
            rooms_sold_target = max(0, min(hotel.total_rooms, rooms_sold_target))

            room_revenue_total = 0.0
            bookings_today = 0
            attempts = 0
            # Distribute today's "sold rooms" across bookings (1-3 nights each)
            while bookings_today < max(1, rooms_sold_target // 2) and attempts < 500:
                attempts += 1
                room_type = random.choice(room_types_by_hotel[hotel.id])
                channel = random.choices(
                    list(CHANNEL_WEIGHTS.keys()), weights=list(CHANNEL_WEIGHTS.values())
                )[0]
                nights = random.choice([1, 1, 2, 2, 3])
                num_guests = random.randint(1, room_type.max_occupancy)

                rate = float(room_type.base_price) * weekend * random.uniform(0.9, 1.15)
                if anomaly_kind == "pricing_error":
                    rate *= 0.4  # a rate-loading mistake that undercuts the room

                nightly_total = rate * nights
                discount = nightly_total * random.choice([0, 0, 0, 0.05, 0.10])
                total_amount = round(nightly_total - discount, 2)

                status = random.choices(
                    [BookingStatus.CHECKED_OUT, BookingStatus.CONFIRMED,
                     BookingStatus.CANCELLED, BookingStatus.NO_SHOW],
                    weights=[0.70, 0.18, 0.09, 0.03],
                )[0]

                customer = random.choice(frequent_guests) if random.random() < 0.4 else random.choice(customers)
                booking_date = day - timedelta(days=random.randint(1, 45))
                lead_time_days = (day - booking_date).days

                booking = Booking(
                    hotel_id=hotel.id,
                    room_type_id=room_type.id,
                    customer_id=customer.id,
                    customer_name=customer.full_name,
                    channel=channel,
                    status=status,
                    booking_date=booking_date,
                    check_in=day,
                    check_out=day + timedelta(days=nights),
                    nights=nights,
                    num_guests=num_guests,
                    total_amount=total_amount,
                    discount_amount=round(discount, 2),
                    lead_time_days=lead_time_days,
                )
                db.add(booking)
                total_bookings += 1
                bookings_today += 1

                if status not in (BookingStatus.CANCELLED, BookingStatus.NO_SHOW):
                    room_revenue_total += total_amount

            fnb_revenue = room_revenue_total * random.uniform(0.15, 0.30)
            other_revenue = room_revenue_total * random.uniform(0.02, 0.08)
            total_revenue = room_revenue_total + fnb_revenue + other_revenue
            actual_rooms_sold = max(1, bookings_today)
            adr = room_revenue_total / actual_rooms_sold if actual_rooms_sold else 0
            occupancy_rate = round(100 * actual_rooms_sold / hotel.total_rooms, 2)
            revpar = round((room_revenue_total / hotel.total_rooms), 2)

            db.add(
                RevenueRecord(
                    hotel_id=hotel.id,
                    date=day,
                    room_revenue=round(room_revenue_total, 2),
                    fnb_revenue=round(fnb_revenue, 2),
                    other_revenue=round(other_revenue, 2),
                    total_revenue=round(total_revenue, 2),
                    rooms_sold=actual_rooms_sold,
                    occupancy_rate=occupancy_rate,
                    adr=round(adr, 2),
                    revpar=revpar,
                )
            )
        db.commit()
        logger.info("Generated {} days of bookings/revenue for {}.", HISTORY_DAYS, hotel.name)

    logger.info("Synthetic data generation complete. Total bookings: {}", total_bookings)


def backfill_customer_features(db: Session) -> None:
    """
    Module 3 (Feature Engineering) applied post-ingestion: computes CLV,
    total_stays, and the repeat-customer flag per customer from the
    bookings we just generated, using the same functions the ETL
    pipeline uses for real uploaded data.
    """
    import pandas as pd

    from app.ml.feature_engineering import compute_customer_lifetime_value

    rows = db.query(
        Booking.customer_id, Booking.total_amount, Booking.status
    ).filter(Booking.customer_id.isnot(None)).all()
    if not rows:
        return

    df = pd.DataFrame(rows, columns=["customer_id", "total_amount", "status"])
    df["status"] = df["status"].apply(lambda s: s.value if hasattr(s, "value") else s)
    features = compute_customer_lifetime_value(df, customer_key="customer_id")

    feature_map = {
        int(row.customer_id): (float(row.lifetime_value), int(row.total_stays), bool(row.is_repeat_customer))
        for row in features.itertuples()
    }

    customers = db.query(Customer).filter(Customer.id.in_(feature_map.keys())).all()
    for customer in customers:
        lifetime_value, total_stays, is_repeat = feature_map[customer.id]
        customer.lifetime_value = round(lifetime_value, 2)
        customer.total_stays = total_stays
        customer.is_repeat_customer = is_repeat
    db.commit()
    logger.info("Backfilled CLV/repeat-customer features for {} customers.", len(customers))


def generate_restaurant_and_spa_sales(db: Session, hotels: list[Hotel]) -> None:
    start_date = date.today() - timedelta(days=HISTORY_DAYS)
    for hotel in hotels:
        for offset in range(HISTORY_DAYS):
            day = start_date + timedelta(days=offset)
            weekend = _weekend_multiplier(day)
            seasonal = _seasonal_multiplier(day)

            covers = int(random.uniform(40, 160) * weekend * seasonal)
            food_revenue = round(covers * random.uniform(28, 55), 2)
            beverage_revenue = round(food_revenue * random.uniform(0.25, 0.45), 2)
            restaurant_total = round(food_revenue + beverage_revenue, 2)
            db.add(
                RestaurantSale(
                    hotel_id=hotel.id,
                    date=day,
                    covers_served=covers,
                    food_revenue=food_revenue,
                    beverage_revenue=beverage_revenue,
                    total_revenue=restaurant_total,
                    avg_check_size=round(restaurant_total / covers, 2) if covers else 0,
                )
            )

            treatments = int(random.uniform(5, 30) * weekend)
            avg_price = random.uniform(80, 220)
            db.add(
                SpaSale(
                    hotel_id=hotel.id,
                    date=day,
                    treatments_booked=treatments,
                    total_revenue=round(treatments * avg_price, 2),
                    avg_treatment_price=round(avg_price, 2),
                )
            )
        db.commit()
    logger.info("Generated restaurant and spa sales for {} hotels.", len(hotels))


def generate_reviews(db: Session, hotels: list[Hotel]) -> None:
    for hotel in hotels:
        for _ in range(random.randint(150, 400)):
            rating = round(min(5.0, max(1.0, random.gauss(4.2, 0.9))), 1)
            sentiment = (
                ReviewSentiment.POSITIVE if rating >= 4
                else ReviewSentiment.NEUTRAL if rating >= 3
                else ReviewSentiment.NEGATIVE
            )
            db.add(
                Review(
                    hotel_id=hotel.id,
                    source=random.choice(REVIEW_SOURCES),
                    rating=rating,
                    sentiment=sentiment,
                    review_text=fake.sentence(nb_words=12),
                    review_date=fake.date_between(start_date=f"-{HISTORY_DAYS}d", end_date="today"),
                )
            )
        db.commit()
    logger.info("Generated reviews for {} hotels.", len(hotels))


def generate_employees(db: Session, hotels: list[Hotel]) -> None:
    for hotel in hotels:
        for _ in range(random.randint(15, 35)):
            department = random.choice(DEPARTMENTS)
            revenue_generated = (
                round(random.uniform(5000, 40000), 2)
                if department in (Department.SALES, Department.FOOD_AND_BEVERAGE, Department.SPA)
                else 0
            )
            db.add(
                Employee(
                    hotel_id=hotel.id,
                    full_name=fake.name(),
                    department=department,
                    hire_date=fake.date_between(start_date="-5y", end_date="-30d"),
                    tasks_completed_mtd=random.randint(20, 200),
                    revenue_generated_mtd=revenue_generated,
                )
            )
        db.commit()
    logger.info("Generated employee records for {} hotels.", len(hotels))


def run() -> None:
    from app.db.session import SessionLocal

    db = SessionLocal()
    try:
        existing = db.query(Hotel).count()
        if existing > 0:
            logger.warning(
                "Hotels already exist in the database ({} found). "
                "Skipping synthetic data generation to avoid duplicates.",
                existing,
            )
            return
        customers = seed_customers(db)
        hotels = seed_hotels_and_room_types(db)
        generate_bookings_and_revenue(db, hotels, customers)
        backfill_customer_features(db)
        generate_restaurant_and_spa_sales(db, hotels)
        generate_reviews(db, hotels)
        generate_employees(db, hotels)
    finally:
        db.close()


if __name__ == "__main__":
    run()
