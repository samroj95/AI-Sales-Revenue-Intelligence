"""
ETL pipeline: aggregates the transactional `bookings` fact table into the
daily `revenue_records` table using Pandas.

Design decision
----------------
This module demonstrates the classic Extract -> Transform -> Load
pattern explicitly, separate from the synthetic data generator:

  * Extract: pull raw bookings for a hotel via SQLAlchemy into a
    DataFrame.
  * Transform: use Pandas groupby/aggregation (not row-by-row Python
    loops) to compute daily room revenue, occupancy, ADR, and RevPAR --
    the same vectorized approach used against a real production
    warehouse table, and dramatically faster than iterating rows.
  * Load: upsert (insert-or-update) into `revenue_records`, keyed by the
    `(hotel_id, date)` unique constraint, so the pipeline is safe to
    re-run (e.g. nightly Airflow/Step Functions job) without creating
    duplicate rows -- a core ETL correctness requirement.

In production this would run as a scheduled AWS Step Functions / Lambda
or Airflow DAG rather than being invoked ad-hoc; the pure function
`aggregate_bookings_to_daily_revenue` is unit-tested independent of any
scheduler.
"""
from datetime import date

import pandas as pd
from loguru import logger
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from app.models.booking import Booking, BookingStatus
from app.models.hotel import Hotel
from app.models.revenue import RevenueRecord


def extract_bookings(db: Session, hotel_id: int) -> pd.DataFrame:
    stmt = select(
        Booking.hotel_id,
        Booking.check_in,
        Booking.total_amount,
        Booking.status,
    ).where(Booking.hotel_id == hotel_id)
    rows = db.execute(stmt).all()
    return pd.DataFrame(rows, columns=["hotel_id", "date", "total_amount", "status"])


def aggregate_bookings_to_daily_revenue(df: pd.DataFrame, total_rooms: int) -> pd.DataFrame:
    """Pure transform function (no DB access) -- easy to unit test."""
    if df.empty:
        return pd.DataFrame(
            columns=["date", "total_revenue", "rooms_sold", "occupancy_rate", "adr", "revpar"]
        )

    honored = df[~df["status"].isin([BookingStatus.CANCELLED, BookingStatus.NO_SHOW])].copy()
    honored["total_amount"] = honored["total_amount"].astype(float)

    daily = (
        honored.groupby("date")
        .agg(total_revenue=("total_amount", "sum"), rooms_sold=("total_amount", "count"))
        .reset_index()
    )
    daily["occupancy_rate"] = (100 * daily["rooms_sold"] / total_rooms).round(2)
    daily["adr"] = (daily["total_revenue"] / daily["rooms_sold"].replace(0, pd.NA)).fillna(0).round(2)
    daily["revpar"] = (daily["total_revenue"] / total_rooms).round(2)
    return daily


def load_daily_revenue(db: Session, hotel_id: int, daily: pd.DataFrame) -> int:
    """Upserts aggregated rows into `revenue_records` keyed on (hotel_id, date)."""
    if daily.empty:
        return 0

    rows = [
        {
            "hotel_id": hotel_id,
            "date": row["date"],
            "room_revenue": row["total_revenue"],
            "fnb_revenue": 0,
            "other_revenue": 0,
            "total_revenue": row["total_revenue"],
            "rooms_sold": int(row["rooms_sold"]),
            "occupancy_rate": row["occupancy_rate"],
            "adr": row["adr"],
            "revpar": row["revpar"],
        }
        for _, row in daily.iterrows()
    ]

    stmt = insert(RevenueRecord).values(rows)
    stmt = stmt.on_conflict_do_update(
        index_elements=["hotel_id", "date"],
        set_={
            "total_revenue": stmt.excluded.total_revenue,
            "room_revenue": stmt.excluded.room_revenue,
            "rooms_sold": stmt.excluded.rooms_sold,
            "occupancy_rate": stmt.excluded.occupancy_rate,
            "adr": stmt.excluded.adr,
            "revpar": stmt.excluded.revpar,
        },
    )
    db.execute(stmt)
    db.commit()
    return len(rows)


def run_etl_for_hotel(db: Session, hotel_id: int) -> int:
    hotel = db.get(Hotel, hotel_id)
    if hotel is None:
        raise ValueError(f"Hotel {hotel_id} not found")

    raw = extract_bookings(db, hotel_id)
    daily = aggregate_bookings_to_daily_revenue(raw, hotel.total_rooms)
    rows_loaded = load_daily_revenue(db, hotel_id, daily)
    logger.info("ETL: refreshed {} daily revenue rows for hotel_id={}", rows_loaded, hotel_id)
    return rows_loaded


def run_etl_for_all_hotels(db: Session) -> dict[int, int]:
    hotel_ids = [h.id for h in db.query(Hotel.id).all()]
    results = {}
    for hotel_id in hotel_ids:
        results[hotel_id] = run_etl_for_hotel(db, hotel_id)
    return results


if __name__ == "__main__":
    from app.db.session import SessionLocal

    session = SessionLocal()
    try:
        summary = run_etl_for_all_hotels(session)
        logger.info("ETL run complete: {}", summary)
    finally:
        session.close()
