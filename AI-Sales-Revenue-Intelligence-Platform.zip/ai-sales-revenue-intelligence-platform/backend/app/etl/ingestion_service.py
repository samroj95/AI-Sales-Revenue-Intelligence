"""
Data ingestion service: reads an uploaded CSV, runs it through cleaning
(Module 2) and feature engineering (Module 3), and bulk-loads it into the
appropriate table.

Design decision
----------------
Each dataset type (bookings, customers, restaurant, spa, reviews,
employees) gets its own small `ingest_*` function sharing one pattern:
read -> clean -> enrich -> bulk insert -> return a structured summary.
This keeps the /upload-data endpoint itself a thin dispatcher (Single
Responsibility) and makes each ingestion path independently testable
against a sample CSV without spinning up FastAPI at all.

Bulk insert (`bulk_insert_mappings`) is used instead of adding ORM
objects one-by-one in a loop -- for a multi-thousand-row CSV this avoids
one flush/identity-map overhead per row, which matters for real PMS
export sizes (tens of thousands of rows/month per property).
"""
from io import BytesIO

import pandas as pd
from loguru import logger
from sqlalchemy.orm import Session

from app.etl.data_cleaning import (
    clean_booking_dataframe,
    fill_missing_categorical,
    fill_missing_numeric,
    parse_currency,
    parse_dates,
    remove_duplicates,
    standardize_country,
)
from app.ml.feature_engineering import enrich_booking_dataframe
from app.models.ancillary import RestaurantSale, SpaSale
from app.models.booking import Booking
from app.models.customer import Customer
from app.models.staff_and_reviews import Employee, Review


class IngestionResult:
    def __init__(self, dataset: str, rows_received: int, rows_loaded: int, rows_rejected: int):
        self.dataset = dataset
        self.rows_received = rows_received
        self.rows_loaded = rows_loaded
        self.rows_rejected = rows_rejected

    def as_dict(self) -> dict:
        return {
            "dataset": self.dataset,
            "rows_received": self.rows_received,
            "rows_loaded": self.rows_loaded,
            "rows_rejected": self.rows_rejected,
        }


def _read_csv(file_bytes: bytes) -> pd.DataFrame:
    return pd.read_csv(BytesIO(file_bytes))


def ingest_bookings_csv(db: Session, file_bytes: bytes, hotel_id: int) -> IngestionResult:
    raw = _read_csv(file_bytes)
    raw["hotel_id"] = hotel_id
    cleaned = clean_booking_dataframe(raw)
    enriched = enrich_booking_dataframe(cleaned)

    records = enriched.to_dict(orient="records")
    valid_columns = {c.name for c in Booking.__table__.columns}
    mappings = [{k: v for k, v in r.items() if k in valid_columns} for r in records]

    if mappings:
        db.bulk_insert_mappings(Booking, mappings)
        db.commit()

    result = IngestionResult("bookings", len(raw), len(mappings), len(raw) - len(mappings))
    logger.info("Ingested bookings CSV: {}", result.as_dict())
    return result


def ingest_customers_csv(db: Session, file_bytes: bytes) -> IngestionResult:
    raw = _read_csv(file_bytes)
    df = raw.copy()
    if "country" in df.columns:
        df["country"] = df["country"].apply(standardize_country)
    df = remove_duplicates(df, subset=["email"] if "email" in df.columns else None)
    df = fill_missing_categorical(df, ["country", "loyalty_tier"])

    valid_columns = {c.name for c in Customer.__table__.columns}
    mappings = [{k: v for k, v in r.items() if k in valid_columns} for r in df.to_dict(orient="records")]
    if mappings:
        db.bulk_insert_mappings(Customer, mappings)
        db.commit()

    return IngestionResult("customers", len(raw), len(mappings), len(raw) - len(mappings))


def ingest_restaurant_csv(db: Session, file_bytes: bytes, hotel_id: int) -> IngestionResult:
    raw = _read_csv(file_bytes)
    df = raw.copy()
    df["hotel_id"] = hotel_id
    for col in ("food_revenue", "beverage_revenue", "total_revenue"):
        if col in df.columns:
            df[col] = df[col].apply(parse_currency)
    if "date" in df.columns:
        df["date"] = parse_dates(df["date"])
    df = fill_missing_numeric(df, ["covers_served", "food_revenue", "beverage_revenue", "total_revenue"])
    df = df.dropna(subset=["date"]) if "date" in df.columns else df

    valid_columns = {c.name for c in RestaurantSale.__table__.columns}
    mappings = [{k: v for k, v in r.items() if k in valid_columns} for r in df.to_dict(orient="records")]
    if mappings:
        db.bulk_insert_mappings(RestaurantSale, mappings)
        db.commit()

    return IngestionResult("restaurant", len(raw), len(mappings), len(raw) - len(mappings))


def ingest_spa_csv(db: Session, file_bytes: bytes, hotel_id: int) -> IngestionResult:
    raw = _read_csv(file_bytes)
    df = raw.copy()
    df["hotel_id"] = hotel_id
    if "total_revenue" in df.columns:
        df["total_revenue"] = df["total_revenue"].apply(parse_currency)
    if "date" in df.columns:
        df["date"] = parse_dates(df["date"])
    df = fill_missing_numeric(df, ["treatments_booked", "total_revenue"])
    df = df.dropna(subset=["date"]) if "date" in df.columns else df

    valid_columns = {c.name for c in SpaSale.__table__.columns}
    mappings = [{k: v for k, v in r.items() if k in valid_columns} for r in df.to_dict(orient="records")]
    if mappings:
        db.bulk_insert_mappings(SpaSale, mappings)
        db.commit()

    return IngestionResult("spa", len(raw), len(mappings), len(raw) - len(mappings))


def ingest_reviews_csv(db: Session, file_bytes: bytes, hotel_id: int) -> IngestionResult:
    raw = _read_csv(file_bytes)
    df = raw.copy()
    df["hotel_id"] = hotel_id
    if "review_date" in df.columns:
        df["review_date"] = parse_dates(df["review_date"])
    df = df.dropna(subset=["review_date"]) if "review_date" in df.columns else df

    valid_columns = {c.name for c in Review.__table__.columns}
    mappings = [{k: v for k, v in r.items() if k in valid_columns} for r in df.to_dict(orient="records")]
    if mappings:
        db.bulk_insert_mappings(Review, mappings)
        db.commit()

    return IngestionResult("reviews", len(raw), len(mappings), len(raw) - len(mappings))


def ingest_employees_csv(db: Session, file_bytes: bytes, hotel_id: int) -> IngestionResult:
    raw = _read_csv(file_bytes)
    df = raw.copy()
    df["hotel_id"] = hotel_id
    if "hire_date" in df.columns:
        df["hire_date"] = parse_dates(df["hire_date"])
    df = fill_missing_numeric(df, ["tasks_completed_mtd", "revenue_generated_mtd"])

    valid_columns = {c.name for c in Employee.__table__.columns}
    mappings = [{k: v for k, v in r.items() if k in valid_columns} for r in df.to_dict(orient="records")]
    if mappings:
        db.bulk_insert_mappings(Employee, mappings)
        db.commit()

    return IngestionResult("employees", len(raw), len(mappings), len(raw) - len(mappings))


DATASET_DISPATCH = {
    "bookings": ingest_bookings_csv,
    "customers": ingest_customers_csv,
    "restaurant": ingest_restaurant_csv,
    "spa": ingest_spa_csv,
    "reviews": ingest_reviews_csv,
    "employees": ingest_employees_csv,
}
