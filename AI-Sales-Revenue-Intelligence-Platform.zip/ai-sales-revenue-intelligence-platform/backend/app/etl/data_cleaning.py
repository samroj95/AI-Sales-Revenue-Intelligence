"""
Data cleaning utilities applied to every raw CSV before it's loaded into
PostgreSQL.

Design decision
----------------
Real hospitality source extracts (PMS exports, OTA reconciliation files,
finance spreadsheets) are notoriously messy: currency values arrive as
"$150", "150 USD", "USD 150", or bare numbers; country names arrive as
"USA", "U.S.A.", "United States"; dates arrive in mixed formats; and
duplicate rows are common from repeated exports. Centralizing these
transforms in pure, unit-testable functions (rather than scattering
ad-hoc `.str.replace()` calls across ingestion code) means every dataset
gets identical guarantees and the transforms can be tested against edge
cases in isolation.
"""
import re

import numpy as np
import pandas as pd

_CURRENCY_TOKEN_RE = re.compile(r"[^\d.\-]")

_COUNTRY_ALIASES = {
    "usa": "United States", "u.s.a.": "United States", "us": "United States",
    "united states of america": "United States",
    "uk": "United Kingdom", "u.k.": "United Kingdom", "britain": "United Kingdom",
    "uae": "United Arab Emirates",
    "korea": "South Korea", "republic of korea": "South Korea",
}


def parse_currency(value) -> float:
    """
    Normalizes "$150", "150 USD", "USD 150", "1,250.50", 150 -> float.
    Returns NaN for unparseable / null input so downstream `fillna`
    handles it consistently rather than silently coercing to 0.
    """
    if pd.isna(value):
        return np.nan
    if isinstance(value, (int, float)):
        return float(value)
    cleaned = _CURRENCY_TOKEN_RE.sub("", str(value).replace(",", ""))
    if cleaned in ("", "-", "."):
        return np.nan
    try:
        return float(cleaned)
    except ValueError:
        return np.nan


def standardize_country(value) -> str:
    if pd.isna(value):
        return "Unknown"
    key = str(value).strip().lower()
    return _COUNTRY_ALIASES.get(key, str(value).strip().title())


def parse_dates(series: pd.Series) -> pd.Series:
    """Coerces mixed-format date strings to datetime, invalid -> NaT (not dropped silently)."""
    return pd.to_datetime(series, errors="coerce", infer_datetime_format=True)


def remove_duplicates(df: pd.DataFrame, subset: list[str] | None = None) -> pd.DataFrame:
    before = len(df)
    df = df.drop_duplicates(subset=subset, keep="first").reset_index(drop=True)
    removed = before - len(df)
    if removed:
        from loguru import logger

        logger.info("Removed {} duplicate rows (subset={}).", removed, subset)
    return df


def fill_missing_numeric(df: pd.DataFrame, columns: list[str], strategy: str = "median") -> pd.DataFrame:
    for col in columns:
        if col not in df.columns:
            continue
        if strategy == "median":
            fill_value = df[col].median()
        elif strategy == "mean":
            fill_value = df[col].mean()
        else:
            fill_value = 0
        df[col] = df[col].fillna(fill_value)
    return df


def fill_missing_categorical(df: pd.DataFrame, columns: list[str], default: str = "Unknown") -> pd.DataFrame:
    for col in columns:
        if col in df.columns:
            df[col] = df[col].fillna(default)
    return df


def detect_outliers_iqr(series: pd.Series, factor: float = 1.5) -> pd.Series:
    """
    Returns a boolean mask of outliers using the IQR method -- robust to
    skewed revenue distributions (unlike a z-score threshold, which
    assumes normality that daily hotel revenue rarely satisfies).
    """
    q1, q3 = series.quantile(0.25), series.quantile(0.75)
    iqr = q3 - q1
    lower, upper = q1 - factor * iqr, q3 + factor * iqr
    return (series < lower) | (series > upper)


def clean_booking_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """End-to-end cleaning pipeline applied to a raw bookings CSV DataFrame."""
    df = df.copy()

    if "total_amount" in df.columns:
        df["total_amount"] = df["total_amount"].apply(parse_currency)
    if "discount_amount" in df.columns:
        df["discount_amount"] = df["discount_amount"].apply(parse_currency)

    for date_col in ("booking_date", "check_in", "check_out"):
        if date_col in df.columns:
            df[date_col] = parse_dates(df[date_col])

    if "country" in df.columns:
        df["country"] = df["country"].apply(standardize_country)

    df = remove_duplicates(df, subset=[c for c in ["customer_name", "check_in", "hotel_id"] if c in df.columns])
    df = fill_missing_numeric(df, ["total_amount", "discount_amount", "nights", "num_guests"])
    df = fill_missing_categorical(df, ["channel", "status", "country"])

    # Drop rows where critical fields are still unusable after cleaning.
    critical = [c for c in ["check_in", "check_out", "hotel_id"] if c in df.columns]
    if critical:
        df = df.dropna(subset=critical)

    return df
