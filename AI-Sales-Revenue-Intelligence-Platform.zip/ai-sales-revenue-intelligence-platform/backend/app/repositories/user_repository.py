"""
Repository pattern for User data access.

Design decision
----------------
Routers/services never issue raw SQLAlchemy queries directly against
`User`. Instead they depend on this repository. This satisfies the
Dependency Inversion Principle: higher-level modules (API endpoints)
depend on an abstraction (repository methods), not on SQLAlchemy query
details -- making it trivial to swap the ORM, add caching, or mock the
repository in unit tests.
"""
from sqlalchemy.orm import Session

from app.core.security import get_password_hash
from app.models.user import User
from app.schemas.user import UserCreate


class UserRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get_by_email(self, email: str) -> User | None:
        return self.db.query(User).filter(User.email == email).first()

    def get_by_id(self, user_id: int) -> User | None:
        return self.db.query(User).filter(User.id == user_id).first()

    def create(self, user_in: UserCreate) -> User:
        user = User(
            email=user_in.email,
            full_name=user_in.full_name,
            hashed_password=get_password_hash(user_in.password),
            role=user_in.role,
        )
        self.db.add(user)
        self.db.commit()
        self.db.refresh(user)
        return user
