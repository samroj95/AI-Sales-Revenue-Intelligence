from datetime import date

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.revenue import RevenueRecord


class RevenueRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get_time_series(
        self,
        hotel_id: int,
        start_date: date | None = None,
        end_date: date | None = None,
    ) -> list[RevenueRecord]:
        stmt = select(RevenueRecord).where(RevenueRecord.hotel_id == hotel_id)
        if start_date is not None:
            stmt = stmt.where(RevenueRecord.date >= start_date)
        if end_date is not None:
            stmt = stmt.where(RevenueRecord.date <= end_date)
        stmt = stmt.order_by(RevenueRecord.date.asc())
        return list(self.db.scalars(stmt).all())

    def kpi_summary(
        self,
        hotel_id: int | None,
        start_date: date | None,
        end_date: date | None,
    ) -> dict:
        stmt = select(
            func.coalesce(func.sum(RevenueRecord.total_revenue), 0),
            func.coalesce(func.avg(RevenueRecord.occupancy_rate), 0),
            func.coalesce(func.avg(RevenueRecord.adr), 0),
            func.coalesce(func.avg(RevenueRecord.revpar), 0),
            func.min(RevenueRecord.date),
            func.max(RevenueRecord.date),
        )
        if hotel_id is not None:
            stmt = stmt.where(RevenueRecord.hotel_id == hotel_id)
        if start_date is not None:
            stmt = stmt.where(RevenueRecord.date >= start_date)
        if end_date is not None:
            stmt = stmt.where(RevenueRecord.date <= end_date)

        row = self.db.execute(stmt).one()
        return {
            "total_revenue": float(row[0]),
            "avg_occupancy_rate": round(float(row[1]), 2),
            "avg_adr": round(float(row[2]), 2),
            "avg_revpar": round(float(row[3]), 2),
            "period_start": row[4],
            "period_end": row[5],
        }
