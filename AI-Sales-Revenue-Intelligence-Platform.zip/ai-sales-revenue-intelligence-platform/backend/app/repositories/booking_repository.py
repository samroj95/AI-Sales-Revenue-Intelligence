from datetime import date

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.booking import Booking, BookingStatus
from app.schemas.booking import BookingCreate


class BookingRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, booking_in: BookingCreate) -> Booking:
        data = booking_in.model_dump()
        # Module 3 feature engineering applied at write time, consistent
        # with the CSV ingestion path (app/etl/ingestion_service.py) and
        # the synthetic data generator, so every Booking row -- however
        # it entered the system -- has lead_time_days populated.
        data["lead_time_days"] = max(0, (data["check_in"] - data["booking_date"]).days)
        booking = Booking(**data)
        self.db.add(booking)
        self.db.commit()
        self.db.refresh(booking)
        return booking

    def get(self, booking_id: int) -> Booking | None:
        return self.db.get(Booking, booking_id)

    def list(
        self,
        *,
        hotel_id: int | None = None,
        channel: str | None = None,
        status: str | None = None,
        start_date: date | None = None,
        end_date: date | None = None,
        page: int = 1,
        page_size: int = 25,
    ) -> tuple[list[Booking], int]:
        stmt = select(Booking)
        if hotel_id is not None:
            stmt = stmt.where(Booking.hotel_id == hotel_id)
        if channel is not None:
            stmt = stmt.where(Booking.channel == channel)
        if status is not None:
            stmt = stmt.where(Booking.status == status)
        if start_date is not None:
            stmt = stmt.where(Booking.check_in >= start_date)
        if end_date is not None:
            stmt = stmt.where(Booking.check_in <= end_date)

        total = self.db.scalar(select(func.count()).select_from(stmt.subquery())) or 0

        stmt = (
            stmt.order_by(Booking.check_in.desc())
            .offset((page - 1) * page_size)
            .limit(page_size)
        )
        items = list(self.db.scalars(stmt).all())
        return items, total

    def cancellation_rate(self, hotel_id: int | None = None) -> float:
        stmt = select(func.count()).select_from(Booking)
        if hotel_id is not None:
            stmt = stmt.where(Booking.hotel_id == hotel_id)
        total = self.db.scalar(stmt) or 0
        if total == 0:
            return 0.0
        cancelled_stmt = stmt.where(Booking.status == BookingStatus.CANCELLED)
        cancelled = self.db.scalar(cancelled_stmt) or 0
        return round(100 * cancelled / total, 2)
