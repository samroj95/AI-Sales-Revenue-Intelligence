from datetime import date

from pydantic import BaseModel, ConfigDict


class RevenueRecordRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    hotel_id: int
    date: date
    room_revenue: float
    fnb_revenue: float
    other_revenue: float
    total_revenue: float
    rooms_sold: int
    occupancy_rate: float
    adr: float
    revpar: float


class KpiSummary(BaseModel):
    total_revenue: float
    avg_occupancy_rate: float
    avg_adr: float
    avg_revpar: float
    total_bookings: int
    cancellation_rate: float
    period_start: date
    period_end: date


class ForecastPoint(BaseModel):
    date: date
    forecast_revenue: float
    lower_bound: float
    upper_bound: float


class ForecastResponse(BaseModel):
    hotel_id: int
    method: str
    horizon_days: int
    history: list[RevenueRecordRead]
    forecast: list[ForecastPoint]


class ModelScore(BaseModel):
    mape: float | None
    rmse: float | None
    status: str


class ForecastComparisonResponse(BaseModel):
    hotel_id: int
    horizon_days: int
    recommended_model: str
    backtest_scores: dict[str, ModelScore]
    forecasts: dict[str, list[ForecastPoint]]


class AnomalyPoint(BaseModel):
    date: date
    total_revenue: float
    z_score: float
    is_anomaly: bool
    severity: str  # "normal" | "moderate" | "severe"


class AnomalyResponse(BaseModel):
    hotel_id: int
    method: str
    anomalies_detected: int
    points: list[AnomalyPoint]
