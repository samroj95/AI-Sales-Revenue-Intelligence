from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=2000)
    hotel_id: int | None = None
    session_id: str | None = None


class SourceChunk(BaseModel):
    content: str
    metadata: dict


class ChatResponse(BaseModel):
    answer: str
    provider: str
    model: str
    sources: list[SourceChunk] = []
