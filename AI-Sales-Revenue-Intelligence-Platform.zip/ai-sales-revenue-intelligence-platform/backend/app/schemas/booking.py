from datetime import date

from pydantic import BaseModel, ConfigDict, Field

from app.models.booking import BookingChannel, BookingStatus


class BookingBase(BaseModel):
    hotel_id: int
    room_type_id: int
    customer_id: int | None = None
    customer_name: str
    channel: BookingChannel
    booking_date: date
    check_in: date
    check_out: date
    nights: int = Field(gt=0)
    num_guests: int = Field(gt=0)
    total_amount: float = Field(ge=0)
    discount_amount: float = Field(ge=0, default=0)


class BookingCreate(BookingBase):
    status: BookingStatus = BookingStatus.CONFIRMED


class BookingRead(BookingBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    status: BookingStatus
    lead_time_days: int


class BookingListResponse(BaseModel):
    total: int
    page: int
    page_size: int
    items: list[BookingRead]
