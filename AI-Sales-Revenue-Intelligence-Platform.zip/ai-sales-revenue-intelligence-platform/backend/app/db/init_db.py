"""
Bootstraps the database: creates all tables and seeds a default admin user.

Design decision
----------------
For this project we use `Base.metadata.create_all()` for simplicity and
reproducibility (one command -> full schema). NOTE: this is a known,
intentional limitation, not an oversight -- Alembic migrations are NOT
implemented here. A real production deployment handling schema changes
after go-live would add Alembic (`pip install alembic`, `alembic init`)
so changes are versioned and reversible; for a fresh single-environment
demo/portfolio deployment, `create_all()` is sufficient and simpler.
This function is intentionally idempotent (checks before inserting) so
it is safe to run repeatedly against an already-initialized database.
"""
from loguru import logger
from sqlalchemy.orm import Session

from app.core.security import get_password_hash
from app.db.base_class import Base
from app.db.session import engine
from app.models.user import User, UserRole


def init_db(db: Session) -> None:
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables ensured (create_all).")

    admin = db.query(User).filter(User.email == "admin@sales-intel.ai").first()
    if not admin:
        admin = User(
            email="admin@sales-intel.ai",
            full_name="Platform Administrator",
            hashed_password=get_password_hash("Admin@12345"),
            role=UserRole.ADMIN,
            is_active=True,
        )
        db.add(admin)
        db.commit()
        logger.info("Seeded default admin user: admin@sales-intel.ai / Admin@12345")
    else:
        logger.info("Admin user already exists, skipping seed.")

    _seed_demo_data_if_empty(db)


def _seed_demo_data_if_empty(db: Session) -> None:
    """
    Auto-populates the synthetic hospitality dataset (Modules 1-3) on a
    fresh deployment, so the executive dashboard, forecasts, and chatbot
    have real data to show immediately after `docker compose up` instead
    of an empty shell -- important for interview/demo reproducibility.
    Controlled by AUTO_SEED_DEMO_DATA (default true); set to false for a
    production deployment that will receive real data via /upload-data.
    """
    from app.core.config import settings
    from app.models.hotel import Hotel

    if not getattr(settings, "AUTO_SEED_DEMO_DATA", True):
        return
    if db.query(Hotel).count() > 0:
        return

    from app.etl.generate_synthetic_data import run as generate_demo_data

    logger.info("No hotels found -- generating synthetic demo dataset (Modules 1-3)...")
    generate_demo_data()
