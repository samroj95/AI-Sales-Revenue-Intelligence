"""
Database engine & session factory.

Design decision
----------------
`pool_pre_ping=True` avoids the classic "MySQL/Postgres server has gone
away" error class when connections idle past the DB's timeout -- important
for long-lived containers. `expire_on_commit=False` lets us return ORM
objects from a request-scoped session without triggering lazy-load errors
after the session closes (common FastAPI + SQLAlchemy pitfall).
"""
from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.core.config import settings

engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=20,
    echo=False,
)

SessionLocal = sessionmaker(
    autocommit=False, autoflush=False, bind=engine, expire_on_commit=False
)


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency that yields a request-scoped DB session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
