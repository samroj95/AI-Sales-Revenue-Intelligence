"""
LLM provider factory.

Design decision
----------------
The chatbot must run in three environments an interviewer might probe:
  * Local dev with no API keys -> Ollama (free, local, no external calls).
  * Cost/latency-optimized cloud inference -> Groq (extremely fast token
    throughput on open models, cheap for a demo).
  * Widest model choice / highest quality -> OpenAI.

Rather than hardcoding one vendor, we implement the Strategy pattern: one
factory function returns a LangChain `BaseChatModel` based on
`settings.LLM_PROVIDER`. Every caller (the RAG chain) depends only on the
LangChain `BaseChatModel` interface, so switching providers is a one-line
.env change with zero code changes elsewhere (Open/Closed Principle).
"""
from langchain_core.language_models import BaseChatModel

from app.core.config import settings


def get_chat_model() -> BaseChatModel:
    provider = settings.LLM_PROVIDER

    if provider == "groq":
        from langchain_groq import ChatGroq

        return ChatGroq(
            api_key=settings.GROQ_API_KEY,
            model=settings.GROQ_MODEL,
            temperature=0.2,
        )

    if provider == "openai":
        from langchain_openai import ChatOpenAI

        return ChatOpenAI(
            api_key=settings.OPENAI_API_KEY,
            model=settings.OPENAI_MODEL,
            temperature=0.2,
        )

    if provider == "ollama":
        from langchain_community.chat_models import ChatOllama

        return ChatOllama(
            base_url=settings.OLLAMA_BASE_URL,
            model=settings.OLLAMA_MODEL,
            temperature=0.2,
        )

    raise ValueError(f"Unsupported LLM_PROVIDER: {provider}")


def get_provider_metadata() -> dict:
    provider = settings.LLM_PROVIDER
    model_map = {
        "groq": settings.GROQ_MODEL,
        "openai": settings.OPENAI_MODEL,
        "ollama": settings.OLLAMA_MODEL,
    }
    return {"provider": provider, "model": model_map.get(provider, "unknown")}
