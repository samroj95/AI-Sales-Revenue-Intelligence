# Hospitality Revenue KPI Glossary

## ADR (Average Daily Rate)
ADR is calculated as total room revenue divided by the number of rooms
sold in a given period. It measures the average price a guest pays per
occupied room, excluding complimentary rooms. Rising ADR alongside stable
occupancy typically signals successful rate optimization; falling ADR
with rising occupancy may signal over-discounting to fill rooms.

## Occupancy Rate
Occupancy rate is the percentage of available rooms that were sold,
computed as rooms sold divided by total available rooms in the period.
It is a volume metric and should always be read together with ADR,
because high occupancy at a heavily discounted rate can still produce
weak RevPAR.

## RevPAR (Revenue Per Available Room)
RevPAR = ADR x Occupancy Rate, or equivalently total room revenue divided
by total available room-nights. It is the single most-watched metric in
hotel revenue management because it captures both pricing and volume in
one number, making it the standard metric for comparing properties of
different sizes.

## Cancellation Rate
The percentage of total bookings that were cancelled before check-in.
A rising cancellation rate can indicate overly permissive cancellation
policies, aggressive overbooking by competitors, or macro disruptions
(e.g. weather, travel advisories).

## Channel Mix
Channel mix describes what share of bookings and revenue comes from each
acquisition channel: direct (hotel website/call center), OTA (Expedia,
Booking.com, etc.), corporate contracts, travel agents, and walk-ins.
Direct and corporate channels typically carry lower distribution costs
than OTA channels, so a healthy channel mix strategy aims to grow direct
share over time without sacrificing total demand.
