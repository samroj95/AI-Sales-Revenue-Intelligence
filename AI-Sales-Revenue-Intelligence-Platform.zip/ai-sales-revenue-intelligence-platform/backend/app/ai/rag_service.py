"""
Retrieval-Augmented Generation (RAG) service for the AI Sales & Revenue
Intelligence chatbot.

Design decision
----------------
The chatbot answers two categories of questions and blends both into one
prompt:

  1. *Domain knowledge* questions ("what does RevPAR mean?", "what's our
     anomaly response policy?") -- answered via vector retrieval over a
     markdown knowledge base (`app/ai/knowledge_base/`) embedded with a
     local Hugging Face sentence-transformer and indexed in FAISS. This
     is the "RAG" part: retrieval grounds the LLM's answer in our actual
     policy documents instead of letting it hallucinate business rules.

  2. *Live data* questions ("what was our RevPAR last month?",
     "any anomalies this week for hotel 3?") -- answered by pulling the
     current KPI summary for the referenced hotel directly from
     PostgreSQL and injecting it as structured context ("context
     stuffing"). This keeps numeric answers grounded in the live
     database rather than a stale vector index snapshot.

The FAISS index is built once (lazily, on first request) and cached in
a module-level singleton -- acceptable for a single-instance demo
deployment; in a multi-instance production deployment this would be
swapped for a persisted vector store (e.g. pgvector or a managed FAISS/
OpenSearch service) shared across replicas.
"""
from pathlib import Path

from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from sqlalchemy.orm import Session

from app.ai.llm_provider import get_chat_model, get_provider_metadata
from app.repositories.revenue_repository import RevenueRepository

KNOWLEDGE_BASE_DIR = Path(__file__).parent / "knowledge_base"

SYSTEM_PROMPT = """You are the AI analyst embedded in a hotel Revenue \
Management platform, serving Admin, Revenue Manager, General Manager, \
Regional Manager, and Finance users. Answer like a sharp revenue-management \
analyst briefing an executive, not like a generic chatbot:

- Lead with the headline number or answer in the first sentence.
- Use concrete figures from the live data context (currency, %, deltas) \
whenever they are available -- never invent numbers that are not in the \
provided context.
- When asked "why" something happened (e.g. a revenue or occupancy drop), \
give the most plausible concrete drivers (seasonality, channel mix shifts, \
cancellations, competitor activity, local events/weather) framed as \
hypotheses to verify, not asserted facts, unless the data context confirms \
them.
- Keep answers tight: 2-5 sentences, or a short bulleted list for \
multi-part questions. Avoid filler ("Great question!", "As an AI...").
- If the answer cannot be determined from the provided context or data, \
say so plainly instead of guessing numbers."""


class _VectorStoreSingleton:
    _store: FAISS | None = None

    @classmethod
    def get(cls) -> FAISS:
        if cls._store is None:
            cls._store = cls._build()
        return cls._store

    @staticmethod
    def _build() -> FAISS:
        splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
        docs: list[Document] = []
        for md_file in sorted(KNOWLEDGE_BASE_DIR.glob("*.md")):
            text = md_file.read_text(encoding="utf-8")
            for chunk in splitter.split_text(text):
                docs.append(Document(page_content=chunk, metadata={"source": md_file.name}))

        embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
        return FAISS.from_documents(docs, embeddings)


class RagChatService:
    def __init__(self, db: Session) -> None:
        self.db = db

    def _retrieve_policy_context(self, query: str, k: int = 3) -> list[Document]:
        store = _VectorStoreSingleton.get()
        return store.similarity_search(query, k=k)

    def _live_kpi_context(self, hotel_id: int | None) -> str:
        if hotel_id is None:
            return "No specific hotel selected; live KPI data not injected."
        summary = RevenueRepository(self.db).kpi_summary(hotel_id, None, None)
        return (
            f"Live KPI snapshot for hotel_id={hotel_id}: "
            f"total_revenue=${summary['total_revenue']:.2f}, "
            f"avg_occupancy_rate={summary['avg_occupancy_rate']}%, "
            f"avg_adr=${summary['avg_adr']}, avg_revpar=${summary['avg_revpar']}, "
            f"period={summary['period_start']} to {summary['period_end']}."
        )

    def answer(self, message: str, hotel_id: int | None = None) -> dict:
        retrieved_docs = self._retrieve_policy_context(message)
        policy_context = "\n---\n".join(d.page_content for d in retrieved_docs)
        live_context = self._live_kpi_context(hotel_id)

        prompt = (
            f"{SYSTEM_PROMPT}\n\n"
            f"# Retrieved policy/knowledge context\n{policy_context}\n\n"
            f"# Live data context\n{live_context}\n\n"
            f"# User question\n{message}\n"
        )

        chat_model = get_chat_model()
        response = chat_model.invoke(prompt)
        meta = get_provider_metadata()

        sources = [
            {"content": d.page_content[:200], "metadata": d.metadata} for d in retrieved_docs
        ]
        return {
            "answer": response.content,
            "provider": meta["provider"],
            "model": meta["model"],
            "sources": sources,
        }
