from sqlalchemy import Date, Enum, ForeignKey, Integer, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import Base, TimestampMixin
import enum


class ReviewSource(str, enum.Enum):
    GOOGLE = "google"
    TRIPADVISOR = "tripadvisor"
    BOOKING_COM = "booking_com"
    EXPEDIA = "expedia"
    DIRECT = "direct"


class ReviewSentiment(str, enum.Enum):
    POSITIVE = "positive"
    NEUTRAL = "neutral"
    NEGATIVE = "negative"


class Review(Base, TimestampMixin):
    """Online guest review, feeding reputation/sentiment analytics."""

    __tablename__ = "reviews"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    hotel_id: Mapped[int] = mapped_column(ForeignKey("hotels.id", ondelete="CASCADE"), index=True)
    source: Mapped[ReviewSource] = mapped_column(Enum(ReviewSource, native_enum=False))
    rating: Mapped[float] = mapped_column(Numeric(3, 2))  # 0.0 - 5.0
    sentiment: Mapped[ReviewSentiment] = mapped_column(
        Enum(ReviewSentiment, native_enum=False), default=ReviewSentiment.NEUTRAL
    )
    review_text: Mapped[str] = mapped_column(Text, nullable=True)
    review_date: Mapped[Date] = mapped_column(Date, index=True)

    hotel: Mapped["Hotel"] = relationship()

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Review hotel_id={self.hotel_id} rating={self.rating}>"


class Department(str, enum.Enum):
    FRONT_OFFICE = "front_office"
    HOUSEKEEPING = "housekeeping"
    FOOD_AND_BEVERAGE = "food_and_beverage"
    SALES = "sales"
    SPA = "spa"
    FINANCE = "finance"


class Employee(Base, TimestampMixin):
    """Staff record used for department productivity / revenue-per-employee KPIs."""

    __tablename__ = "employees"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    hotel_id: Mapped[int] = mapped_column(ForeignKey("hotels.id", ondelete="CASCADE"), index=True)
    full_name: Mapped[str] = mapped_column(String(255), nullable=False)
    department: Mapped[Department] = mapped_column(Enum(Department, native_enum=False))
    hire_date: Mapped[Date] = mapped_column(Date, nullable=True)
    tasks_completed_mtd: Mapped[int] = mapped_column(Integer, default=0)
    revenue_generated_mtd: Mapped[float] = mapped_column(Numeric(12, 2), default=0)

    hotel: Mapped["Hotel"] = relationship()

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Employee id={self.id} department={self.department}>"
