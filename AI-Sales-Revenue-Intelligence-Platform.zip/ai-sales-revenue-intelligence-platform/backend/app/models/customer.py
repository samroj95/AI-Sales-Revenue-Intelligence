from sqlalchemy import Boolean, Date, Integer, Numeric, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import Base, TimestampMixin


class Customer(Base, TimestampMixin):
    """
    A guest / loyalty profile, deduplicated across booking sources during
    ingestion (see app/etl/data_cleaning.py). Backing table for CLV,
    repeat-customer %, and loyalty-tier analytics.
    """

    __tablename__ = "customers"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    full_name: Mapped[str] = mapped_column(String(255), nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    country: Mapped[str] = mapped_column(String(120), nullable=False)
    is_loyalty_member: Mapped[bool] = mapped_column(Boolean, default=False)
    loyalty_tier: Mapped[str] = mapped_column(String(50), default="none")  # none|silver|gold|platinum
    join_date: Mapped[Date] = mapped_column(Date, nullable=True)

    # Derived by app/ml/feature_engineering.py -- persisted for fast dashboard reads.
    lifetime_value: Mapped[float] = mapped_column(Numeric(12, 2), default=0)
    total_stays: Mapped[int] = mapped_column(Integer, default=0)
    is_repeat_customer: Mapped[bool] = mapped_column(Boolean, default=False)

    bookings: Mapped[list["Booking"]] = relationship(back_populates="customer")

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Customer id={self.id} email={self.email!r}>"
