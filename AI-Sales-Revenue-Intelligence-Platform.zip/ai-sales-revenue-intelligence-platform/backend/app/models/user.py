"""
User model.

Design decision
----------------
`role` is a simple string-backed enum rather than a separate roles/
permissions table. The platform models the five real hotel-group
personas called out in the spec: ADMIN (platform/IT), REVENUE_MANAGER
(pricing, forecasts, anomalies), GENERAL_MANAGER (single-property
executive view), REGIONAL_MANAGER (multi-property/portfolio view), and
FINANCE (revenue reconciliation, reporting/export). If the platform grew
to need fine-grained per-resource permissions, this would be refactored
into a `roles` + `permissions` + `role_permissions` join-table design
without touching the rest of the codebase (Open/Closed Principle).
"""
import enum

from sqlalchemy import Boolean, Enum, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base_class import Base, TimestampMixin


class UserRole(str, enum.Enum):
    ADMIN = "admin"
    REVENUE_MANAGER = "revenue_manager"
    GENERAL_MANAGER = "general_manager"
    REGIONAL_MANAGER = "regional_manager"
    FINANCE = "finance"


class User(Base, TimestampMixin):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    full_name: Mapped[str] = mapped_column(String(255), nullable=False)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[UserRole] = mapped_column(
        Enum(UserRole, native_enum=False), default=UserRole.REVENUE_MANAGER, nullable=False
    )
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    def __repr__(self) -> str:  # pragma: no cover
        return f"<User id={self.id} email={self.email!r} role={self.role}>"
