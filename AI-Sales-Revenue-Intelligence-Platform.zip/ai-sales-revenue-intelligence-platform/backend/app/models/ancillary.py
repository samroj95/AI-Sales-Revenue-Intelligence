from sqlalchemy import Date, ForeignKey, Integer, Numeric, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import Base, TimestampMixin


class RestaurantSale(Base, TimestampMixin):
    """Daily F&B (restaurant/bar) sales per hotel, feeding the Restaurant Dashboard."""

    __tablename__ = "restaurant_sales"
    __table_args__ = (UniqueConstraint("hotel_id", "date", name="uq_restaurant_hotel_date"),)

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    hotel_id: Mapped[int] = mapped_column(ForeignKey("hotels.id", ondelete="CASCADE"), index=True)
    date: Mapped[Date] = mapped_column(Date, index=True, nullable=False)

    covers_served: Mapped[int] = mapped_column(Integer, default=0)  # # of diners
    food_revenue: Mapped[float] = mapped_column(Numeric(12, 2), default=0)
    beverage_revenue: Mapped[float] = mapped_column(Numeric(12, 2), default=0)
    total_revenue: Mapped[float] = mapped_column(Numeric(12, 2), default=0)
    avg_check_size: Mapped[float] = mapped_column(Numeric(10, 2), default=0)

    hotel: Mapped["Hotel"] = relationship()

    def __repr__(self) -> str:  # pragma: no cover
        return f"<RestaurantSale hotel_id={self.hotel_id} date={self.date}>"


class SpaSale(Base, TimestampMixin):
    """Daily spa & wellness revenue per hotel, feeding ancillary-revenue KPIs."""

    __tablename__ = "spa_sales"
    __table_args__ = (UniqueConstraint("hotel_id", "date", name="uq_spa_hotel_date"),)

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    hotel_id: Mapped[int] = mapped_column(ForeignKey("hotels.id", ondelete="CASCADE"), index=True)
    date: Mapped[Date] = mapped_column(Date, index=True, nullable=False)

    treatments_booked: Mapped[int] = mapped_column(Integer, default=0)
    total_revenue: Mapped[float] = mapped_column(Numeric(12, 2), default=0)
    avg_treatment_price: Mapped[float] = mapped_column(Numeric(10, 2), default=0)

    hotel: Mapped["Hotel"] = relationship()

    def __repr__(self) -> str:  # pragma: no cover
        return f"<SpaSale hotel_id={self.hotel_id} date={self.date}>"
