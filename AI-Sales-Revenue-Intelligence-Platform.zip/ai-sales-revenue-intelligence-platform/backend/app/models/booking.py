import enum

from sqlalchemy import Date, Enum, ForeignKey, Integer, Numeric, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import Base, TimestampMixin


class BookingChannel(str, enum.Enum):
    DIRECT = "direct"
    OTA = "ota"
    CORPORATE = "corporate"
    TRAVEL_AGENT = "travel_agent"
    WALK_IN = "walk_in"


class BookingStatus(str, enum.Enum):
    CONFIRMED = "confirmed"
    CANCELLED = "cancelled"
    NO_SHOW = "no_show"
    CHECKED_OUT = "checked_out"


class Booking(Base, TimestampMixin):
    """
    A single reservation transaction. This is the atomic fact table that
    ETL jobs aggregate into daily `RevenueRecord`s for BI/forecasting.
    """

    __tablename__ = "bookings"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    hotel_id: Mapped[int] = mapped_column(ForeignKey("hotels.id", ondelete="CASCADE"), index=True)
    room_type_id: Mapped[int] = mapped_column(ForeignKey("room_types.id", ondelete="CASCADE"))
    customer_id: Mapped[int | None] = mapped_column(
        ForeignKey("customers.id", ondelete="SET NULL"), nullable=True, index=True
    )

    customer_name: Mapped[str] = mapped_column(String(255), nullable=False)
    channel: Mapped[BookingChannel] = mapped_column(Enum(BookingChannel, native_enum=False))
    status: Mapped[BookingStatus] = mapped_column(
        Enum(BookingStatus, native_enum=False), default=BookingStatus.CONFIRMED
    )

    booking_date: Mapped[Date] = mapped_column(Date, index=True)
    check_in: Mapped[Date] = mapped_column(Date, index=True)
    check_out: Mapped[Date] = mapped_column(Date)
    nights: Mapped[int] = mapped_column(Integer)
    num_guests: Mapped[int] = mapped_column(Integer, default=1)

    total_amount: Mapped[float] = mapped_column(Numeric(10, 2))
    discount_amount: Mapped[float] = mapped_column(Numeric(10, 2), default=0)

    # Feature-engineered at ingestion time (Module 3): days between booking_date
    # and check_in. Core driver of demand-forecasting and pricing models.
    lead_time_days: Mapped[int] = mapped_column(Integer, default=0)

    hotel: Mapped["Hotel"] = relationship(back_populates="bookings")
    room_type: Mapped["RoomType"] = relationship(back_populates="bookings")
    customer: Mapped["Customer"] = relationship(back_populates="bookings")

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Booking id={self.id} hotel_id={self.hotel_id} status={self.status}>"
