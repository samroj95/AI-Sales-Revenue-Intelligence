"""
Import every model module here so that `Base.metadata` is fully populated
before `Base.metadata.create_all()` or Alembic autogeneration runs.
"""
from app.models.user import User  # noqa: F401
from app.models.hotel import Hotel, RoomType  # noqa: F401
from app.models.customer import Customer  # noqa: F401
from app.models.booking import Booking, BookingChannel, BookingStatus  # noqa: F401
from app.models.revenue import RevenueRecord  # noqa: F401
from app.models.ancillary import RestaurantSale, SpaSale  # noqa: F401
from app.models.staff_and_reviews import Review, ReviewSource, ReviewSentiment, Employee, Department  # noqa: F401
