from sqlalchemy import Date, ForeignKey, Numeric, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import Base, TimestampMixin


class RevenueRecord(Base, TimestampMixin):
    """
    Daily, per-hotel aggregated revenue metrics.

    Design decision
    ----------------
    Forecasting and anomaly detection operate far more efficiently over a
    pre-aggregated daily grain than over raw bookings. The ETL pipeline
    (see app/etl/etl_pipeline.py) is responsible for populating this table
    from `bookings`, keeping the read path for dashboards/ML O(days) instead
    of O(bookings). This mirrors a classic star-schema fact table used in
    real hospitality revenue-management systems (RevPAR/ADR reporting).
    """

    __tablename__ = "revenue_records"
    __table_args__ = (UniqueConstraint("hotel_id", "date", name="uq_hotel_date"),)

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    hotel_id: Mapped[int] = mapped_column(ForeignKey("hotels.id", ondelete="CASCADE"), index=True)
    date: Mapped[Date] = mapped_column(Date, index=True, nullable=False)

    room_revenue: Mapped[float] = mapped_column(Numeric(12, 2), default=0)
    fnb_revenue: Mapped[float] = mapped_column(Numeric(12, 2), default=0)
    other_revenue: Mapped[float] = mapped_column(Numeric(12, 2), default=0)
    total_revenue: Mapped[float] = mapped_column(Numeric(12, 2), default=0)

    rooms_sold: Mapped[int] = mapped_column(default=0)
    occupancy_rate: Mapped[float] = mapped_column(Numeric(5, 2), default=0)  # %
    adr: Mapped[float] = mapped_column(Numeric(10, 2), default=0)  # Average Daily Rate
    revpar: Mapped[float] = mapped_column(Numeric(10, 2), default=0)  # Revenue per Available Room

    hotel: Mapped["Hotel"] = relationship(back_populates="revenue_records")

    def __repr__(self) -> str:  # pragma: no cover
        return f"<RevenueRecord hotel_id={self.hotel_id} date={self.date} total={self.total_revenue}>"
