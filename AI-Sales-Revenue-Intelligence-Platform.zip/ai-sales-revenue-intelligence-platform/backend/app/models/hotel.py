from sqlalchemy import ForeignKey, Integer, Numeric, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import Base, TimestampMixin


class Hotel(Base, TimestampMixin):
    """A property in the hospitality portfolio."""

    __tablename__ = "hotels"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    city: Mapped[str] = mapped_column(String(120), nullable=False)
    country: Mapped[str] = mapped_column(String(120), nullable=False)
    star_rating: Mapped[int] = mapped_column(Integer, default=3)
    total_rooms: Mapped[int] = mapped_column(Integer, nullable=False)

    room_types: Mapped[list["RoomType"]] = relationship(
        back_populates="hotel", cascade="all, delete-orphan"
    )
    bookings: Mapped[list["Booking"]] = relationship(back_populates="hotel")
    revenue_records: Mapped[list["RevenueRecord"]] = relationship(back_populates="hotel")

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Hotel id={self.id} name={self.name!r}>"


class RoomType(Base, TimestampMixin):
    """A sellable room category (e.g. Deluxe King, Suite) within a hotel."""

    __tablename__ = "room_types"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    hotel_id: Mapped[int] = mapped_column(ForeignKey("hotels.id", ondelete="CASCADE"))
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    base_price: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False)
    max_occupancy: Mapped[int] = mapped_column(Integer, default=2)

    hotel: Mapped["Hotel"] = relationship(back_populates="room_types")
    bookings: Mapped[list["Booking"]] = relationship(back_populates="room_type")

    def __repr__(self) -> str:  # pragma: no cover
        return f"<RoomType id={self.id} name={self.name!r} hotel_id={self.hotel_id}>"
