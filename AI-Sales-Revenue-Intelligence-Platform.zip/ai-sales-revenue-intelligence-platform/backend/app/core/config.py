"""
Application configuration.

Design decision
----------------
We centralize *all* environment-driven configuration in a single Pydantic
`Settings` object (12-factor app style). This gives us:
  * Type-validated config (fails fast at startup, not at 2am in prod).
  * A single import (`from app.core.config import settings`) everywhere,
    instead of scattered `os.environ.get(...)` calls.
  * Easy overriding per-environment (dev / staging / prod) via `.env` files
    or real environment variables injected by Docker/K8s/ECS.
"""
from functools import lru_cache
from typing import List, Literal

from pydantic import AnyHttpUrl, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # --- Application -------------------------------------------------
    PROJECT_NAME: str = "AI Sales & Revenue Intelligence Platform"
    API_V1_STR: str = "/api/v1"
    ENVIRONMENT: Literal["development", "staging", "production"] = "development"
    DEBUG: bool = True
    AUTO_SEED_DEMO_DATA: bool = True

    # --- Security ------------------------------------------------------
    SECRET_KEY: str = "insecure-dev-key-override-me"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    REFRESH_TOKEN_EXPIRE_MINUTES: int = 10080

    # --- Database --------------------------------------------------
    POSTGRES_SERVER: str = "db"
    POSTGRES_PORT: int = 5432
    POSTGRES_USER: str = "sales_admin"
    POSTGRES_PASSWORD: str = "sales_secret_pw"
    POSTGRES_DB: str = "sales_revenue_intelligence"
    DATABASE_URL: str | None = None

    @field_validator("DATABASE_URL", mode="before")
    @classmethod
    def assemble_db_url(cls, v: str | None, info) -> str:
        if isinstance(v, str) and v:
            return v
        data = info.data
        return (
            f"postgresql+psycopg2://{data.get('POSTGRES_USER')}:"
            f"{data.get('POSTGRES_PASSWORD')}@{data.get('POSTGRES_SERVER')}:"
            f"{data.get('POSTGRES_PORT')}/{data.get('POSTGRES_DB')}"
        )

    # --- CORS ------------------------------------------------------------
    BACKEND_CORS_ORIGINS: List[AnyHttpUrl] | List[str] = ["http://localhost:3000"]

    # --- LLM / AI --------------------------------------------------------
    LLM_PROVIDER: Literal["groq", "openai", "ollama"] = "groq"
    GROQ_API_KEY: str = ""
    GROQ_MODEL: str = "llama-3.1-70b-versatile"
    OPENAI_API_KEY: str = ""
    OPENAI_MODEL: str = "gpt-4o-mini"
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "llama3.1"

    # --- AWS ---------------------------------------------------------------
    AWS_ACCESS_KEY_ID: str = ""
    AWS_SECRET_ACCESS_KEY: str = ""
    AWS_REGION: str = "us-east-1"
    AWS_S3_BUCKET: str = "ai-sales-revenue-intelligence-data"

    # --- Logging -------------------------------------------------------
    LOG_LEVEL: str = "INFO"
    LOG_JSON: bool = False

    # --- Alerts (Module 8) -------------------------------------------
    SMTP_HOST: str = "smtp.sendgrid.net"
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    ALERT_EMAIL_FROM: str = "alerts@sales-intel.ai"
    ALERT_EMAIL_TO: str = "revenue-team@example.com"
    SLACK_WEBHOOK_URL: str = ""
    REVENUE_DROP_THRESHOLD_PCT: float = 15.0
    OCCUPANCY_ALERT_THRESHOLD_PCT: float = 55.0
    CANCELLATION_ALERT_THRESHOLD_PCT: float = 20.0

    model_config = SettingsConfigDict(env_file=".env", case_sensitive=True, extra="ignore")


@lru_cache
def get_settings() -> Settings:
    """Cached settings singleton so we parse the environment only once."""
    return Settings()


settings = get_settings()
