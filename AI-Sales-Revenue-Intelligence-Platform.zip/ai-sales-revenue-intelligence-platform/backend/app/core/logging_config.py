"""
Centralized logging configuration.

Design decision
----------------
We use `loguru` instead of stdlib `logging` directly because it gives us:
  * Sane defaults (no boilerplate handler/formatter setup).
  * Built-in JSON serialization for log aggregation (CloudWatch / ELK).
  * Automatic exception traceback formatting.

We intercept stdlib logging (used internally by uvicorn/sqlalchemy) and
redirect it through loguru so every log line in the service -- ours and
third-party -- shares one consistent format and one sink configuration.
This matters in production where logs are shipped to CloudWatch/Datadog
and inconsistent formats make querying painful.
"""
import logging
import sys

from loguru import logger

from app.core.config import settings


class InterceptHandler(logging.Handler):
    """Redirects stdlib logging records into loguru."""

    def emit(self, record: logging.LogRecord) -> None:
        try:
            level = logger.level(record.levelname).name
        except ValueError:
            level = record.levelno

        frame, depth = logging.currentframe(), 2
        while frame.f_back and "logging" in frame.f_code.co_filename:
            frame = frame.f_back
            depth += 1

        logger.opt(depth=depth, exception=record.exc_info).log(
            level, record.getMessage()
        )


def configure_logging() -> None:
    logger.remove()
    sink_kwargs = {
        "level": settings.LOG_LEVEL,
        "backtrace": True,
        "diagnose": settings.ENVIRONMENT != "production",
    }
    if settings.LOG_JSON:
        logger.add(sys.stdout, serialize=True, **sink_kwargs)
    else:
        logger.add(
            sys.stdout,
            format=(
                "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
                "<level>{level: <8}</level> | "
                "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> "
                "- <level>{message}</level>"
            ),
            **sink_kwargs,
        )

    for name in ("uvicorn", "uvicorn.access", "uvicorn.error", "sqlalchemy.engine"):
        logging.getLogger(name).handlers = [InterceptHandler()]
        logging.getLogger(name).propagate = False

    logging.basicConfig(handlers=[InterceptHandler()], level=0, force=True)
