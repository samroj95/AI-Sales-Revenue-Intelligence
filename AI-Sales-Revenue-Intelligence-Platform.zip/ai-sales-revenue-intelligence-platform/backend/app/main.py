"""
FastAPI application entrypoint.

Design decision
----------------
Startup responsibilities (logging config, DB bootstrap) live in a
`lifespan` context manager rather than deprecated `@app.on_event`
handlers, matching current FastAPI best practice. CORS, a global
exception handler (so unhandled errors return a consistent JSON shape
instead of leaking stack traces), and request logging middleware are
configured once here and apply uniformly to every route.
"""
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from loguru import logger

from app.api.v1.router import api_router
from app.core.config import settings
from app.core.logging_config import configure_logging
from app.db.init_db import init_db
from app.db.session import SessionLocal


@asynccontextmanager
async def lifespan(app: FastAPI):
    configure_logging()
    logger.info("Starting {} [{}]", settings.PROJECT_NAME, settings.ENVIRONMENT)
    db = SessionLocal()
    try:
        init_db(db)
    finally:
        db.close()
    yield
    logger.info("Shutting down {}", settings.PROJECT_NAME)


app = FastAPI(
    title=settings.PROJECT_NAME,
    description=(
        "Enterprise-grade AI-powered platform for hospitality sales & "
        "revenue intelligence: forecasting, anomaly detection, executive "
        "dashboards, and a RAG-based conversational analyst."
    ),
    version="1.0.0",
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
    docs_url=f"{settings.API_V1_STR}/docs",
    redoc_url=f"{settings.API_V1_STR}/redoc",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[str(origin) for origin in settings.BACKEND_CORS_ORIGINS] or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.perf_counter()
    response = await call_next(request)
    duration_ms = (time.perf_counter() - start) * 1000
    logger.info(
        "{} {} -> {} ({:.2f} ms)",
        request.method,
        request.url.path,
        response.status_code,
        duration_ms,
    )
    return response


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    logger.exception("Unhandled exception on {} {}", request.method, request.url.path)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "An internal server error occurred."},
    )


@app.get("/health", tags=["Health"])
def health_check() -> dict:
    """Liveness/readiness probe endpoint for Docker/K8s/ALB health checks."""
    return {"status": "ok", "service": settings.PROJECT_NAME, "environment": settings.ENVIRONMENT}


app.include_router(api_router, prefix=settings.API_V1_STR)

# ---------------------------------------------------------------------------
# Prometheus metrics (Module: Monitoring)
# ---------------------------------------------------------------------------
# Design decision: `prometheus-fastapi-instrumentator` auto-instruments
# request count/latency/in-progress gauges per route with zero endpoint
# boilerplate, and exposes them at /metrics for a Prometheus server to
# scrape (see monitoring/prometheus.yml). Grafana then reads from
# Prometheus -- the standard, vendor-neutral observability stack used in
# most AWS/Kubernetes deployments, as opposed to CloudWatch-only metrics
# which would lock the demo to one cloud.
from prometheus_fastapi_instrumentator import Instrumentator  # noqa: E402

Instrumentator().instrument(app).expose(app, endpoint="/metrics", include_in_schema=False)
