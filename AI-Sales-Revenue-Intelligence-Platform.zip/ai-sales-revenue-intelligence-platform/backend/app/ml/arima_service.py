"""
ARIMA / SARIMAX forecasting service.

Design decision
----------------
We use `statsmodels.SARIMAX` (Seasonal ARIMA) rather than a bare ARIMA,
because hotel revenue has a clear weekly seasonal period (m=7). SARIMAX
is included as the classical statistical baseline in the ensemble --
it's the model most revenue-management and finance teams already
recognize and trust, and it produces principled confidence intervals
(unlike our Holt-Winters residual-std approximation), which matters when
comparing calibration across models in the ensemble comparison report.

Order selection: rather than a full grid-search (expensive per-request),
we use a small, well-established default (p,d,q)=(1,1,1),
(P,D,Q,m)=(1,1,1,7) which is a reasonable general-purpose seasonal
specification for daily business data; a production system would run
`pmdarima.auto_arima` offline periodically and cache the chosen order.
"""
import pandas as pd
from statsmodels.tsa.statespace.sarimax import SARIMAX


class ArimaForecastingService:
    def forecast(self, history: list[dict], horizon_days: int = 14) -> list[dict]:
        df = pd.DataFrame(history)
        df["date"] = pd.to_datetime(df["date"])
        df = df.set_index("date").asfreq("D")
        series = df["total_revenue"].interpolate().fillna(method="bfill")

        model = SARIMAX(
            series,
            order=(1, 1, 1),
            seasonal_order=(1, 1, 1, 7),
            enforce_stationarity=False,
            enforce_invertibility=False,
        )
        fitted = model.fit(disp=False)
        forecast_result = fitted.get_forecast(steps=horizon_days)
        mean = forecast_result.predicted_mean
        conf_int = forecast_result.conf_int(alpha=0.05)

        points = []
        for i in range(horizon_days):
            date = mean.index[i].date()
            points.append(
                {
                    "date": date,
                    "forecast_revenue": max(0.0, round(float(mean.iloc[i]), 2)),
                    "lower_bound": max(0.0, round(float(conf_int.iloc[i, 0]), 2)),
                    "upper_bound": round(float(conf_int.iloc[i, 1]), 2),
                }
            )
        return points
