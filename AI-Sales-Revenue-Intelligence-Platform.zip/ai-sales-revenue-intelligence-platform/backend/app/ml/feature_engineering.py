"""
Feature engineering: derives the business metrics executives actually
look at from cleaned raw transactional data.

Design decision
----------------
Every formula here is implemented once as a small, pure, independently
testable function operating on Pandas Series/DataFrames -- not
recomputed ad-hoc inside API endpoints. This is the same logic the ETL
pipeline uses to populate `revenue_records`/`customers`, and what unit
tests validate directly (see tests/test_feature_engineering.py),
guaranteeing the dashboard, the forecasting models, and the chatbot's
"live KPI" context all read numbers computed by the exact same code path.
"""
import numpy as np
import pandas as pd


def compute_adr(room_revenue: pd.Series, rooms_sold: pd.Series) -> pd.Series:
    """Average Daily Rate = room revenue / rooms sold."""
    return (room_revenue / rooms_sold.replace(0, np.nan)).fillna(0).round(2)


def compute_revpar(room_revenue: pd.Series, total_rooms: int) -> pd.Series:
    """Revenue per Available Room = room revenue / total available rooms."""
    if total_rooms <= 0:
        return pd.Series(0, index=room_revenue.index)
    return (room_revenue / total_rooms).round(2)


def compute_occupancy_rate(rooms_sold: pd.Series, total_rooms: int) -> pd.Series:
    if total_rooms <= 0:
        return pd.Series(0, index=rooms_sold.index)
    return (100 * rooms_sold / total_rooms).round(2)


def compute_revenue_growth_pct(revenue: pd.Series) -> pd.Series:
    """Period-over-period % growth, sorted ascending by date beforehand."""
    return (revenue.pct_change() * 100).round(2).fillna(0)


def compute_average_stay(nights: pd.Series) -> float:
    return round(float(nights.mean()), 2) if len(nights) else 0.0


def compute_booking_lead_time(booking_date: pd.Series, check_in: pd.Series) -> pd.Series:
    """Days between the booking being made and the guest's arrival."""
    return (pd.to_datetime(check_in) - pd.to_datetime(booking_date)).dt.days.clip(lower=0)


def compute_cancellation_rate(status: pd.Series, cancelled_values: tuple[str, ...] = ("cancelled", "no_show")) -> float:
    if len(status) == 0:
        return 0.0
    cancelled = status.astype(str).str.lower().isin(cancelled_values).sum()
    return round(100 * cancelled / len(status), 2)


def compute_weekend_weekday_split(df: pd.DataFrame, date_col: str, revenue_col: str) -> dict:
    """Splits total revenue into weekend (Fri/Sat) vs weekday buckets."""
    dates = pd.to_datetime(df[date_col])
    is_weekend = dates.dt.weekday.isin([4, 5])
    weekend_revenue = float(df.loc[is_weekend, revenue_col].sum())
    weekday_revenue = float(df.loc[~is_weekend, revenue_col].sum())
    return {"weekend_revenue": round(weekend_revenue, 2), "weekday_revenue": round(weekday_revenue, 2)}


def compute_customer_lifetime_value(bookings_df: pd.DataFrame, customer_key: str = "customer_id") -> pd.DataFrame:
    """
    CLV per customer = sum of honored (non-cancelled) booking revenue.
    Returns a DataFrame indexed by customer with lifetime_value,
    total_stays, and an is_repeat_customer flag (>= 2 stays).
    """
    honored = bookings_df[~bookings_df["status"].astype(str).str.lower().isin(["cancelled", "no_show"])]
    grouped = honored.groupby(customer_key).agg(
        lifetime_value=("total_amount", "sum"), total_stays=("total_amount", "count")
    )
    grouped["lifetime_value"] = grouped["lifetime_value"].round(2)
    grouped["is_repeat_customer"] = grouped["total_stays"] >= 2
    return grouped.reset_index()


def compute_repeat_customer_pct(customer_features: pd.DataFrame) -> float:
    if customer_features.empty:
        return 0.0
    return round(100 * customer_features["is_repeat_customer"].mean(), 2)


def enrich_booking_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Adds lead_time_days to a cleaned bookings DataFrame in-place-safe fashion."""
    df = df.copy()
    if {"booking_date", "check_in"}.issubset(df.columns):
        df["lead_time_days"] = compute_booking_lead_time(df["booking_date"], df["check_in"])
    return df
