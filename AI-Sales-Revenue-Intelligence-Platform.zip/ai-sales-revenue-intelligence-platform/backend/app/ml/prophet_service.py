"""
Facebook Prophet forecasting service.

Design decision
----------------
Prophet is included as one of three ensemble members (spec requirement)
specifically because it handles multiple seasonalities (weekly + yearly)
and holiday effects out of the box via an additive decomposition
(trend + seasonality + holiday), which is exactly the shape of hotel
demand data (weekend premiums + summer/holiday peaks). It is slower to
fit than Holt-Winters and needs more history to be reliable, which is
why the comparison service (forecast_comparison_service.py) backtests it
against the alternatives rather than assuming it always wins.
"""
import pandas as pd
from prophet import Prophet


class ProphetForecastingService:
    def forecast(self, history: list[dict], horizon_days: int = 14) -> list[dict]:
        df = pd.DataFrame(history)[["date", "total_revenue"]].rename(
            columns={"date": "ds", "total_revenue": "y"}
        )
        df["ds"] = pd.to_datetime(df["ds"])

        model = Prophet(
            weekly_seasonality=True,
            yearly_seasonality=len(df) >= 365,
            daily_seasonality=False,
            interval_width=0.95,
        )
        model.fit(df)

        future = model.make_future_dataframe(periods=horizon_days)
        forecast_df = model.predict(future).tail(horizon_days)

        return [
            {
                "date": row.ds.date(),
                "forecast_revenue": max(0.0, round(float(row.yhat), 2)),
                "lower_bound": max(0.0, round(float(row.yhat_lower), 2)),
                "upper_bound": round(float(row.yhat_upper), 2),
            }
            for row in forecast_df.itertuples()
        ]
