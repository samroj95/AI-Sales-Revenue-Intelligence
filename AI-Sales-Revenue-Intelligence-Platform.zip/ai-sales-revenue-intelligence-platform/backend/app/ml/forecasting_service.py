"""
Revenue forecasting service.

Design decision
----------------
We use Holt-Winters Exponential Smoothing (statsmodels) rather than
Facebook Prophet. Rationale for interviews:
  * Prophet pulls in a heavy Stan/cmdstanpy toolchain that complicates
    Docker images and cold-start time; Holt-Winters needs only
    numpy/pandas/statsmodels (already in our stack).
  * Hospitality revenue has strong weekly seasonality (weekend vs.
    weekday) and sometimes yearly seasonality; Holt-Winters models trend
    + seasonality directly and is battle-tested for exactly this use case
    in revenue management systems.
  * For a short history (<2 full seasonal cycles) we fall back to a
    simple weighted moving-average + linear trend model so the API never
    crashes on sparse data -- graceful degradation over hard failure.

The service returns a point forecast with a naive confidence band
(historical residual std-dev) which is sufficient for dashboard display
and is clearly documented as an approximation, not a formal prediction
interval.
"""
from datetime import timedelta

import numpy as np
import pandas as pd
from statsmodels.tsa.holtwinters import ExponentialSmoothing

MIN_POINTS_FOR_SEASONAL_MODEL = 21  # ~3 weeks, enough for weekly seasonality


class ForecastingService:
    def forecast(
        self, history: list[dict], horizon_days: int = 14
    ) -> tuple[str, list[dict]]:
        """
        Parameters
        ----------
        history: list of {"date": date, "total_revenue": float} sorted ascending.
        horizon_days: number of future days to forecast.

        Returns
        -------
        (method_name, list of forecast points)
        """
        if len(history) < 5:
            return "insufficient_data", []

        df = pd.DataFrame(history)
        df["date"] = pd.to_datetime(df["date"])
        df = df.set_index("date").asfreq("D")
        df["total_revenue"] = df["total_revenue"].interpolate().fillna(method="bfill")

        series = df["total_revenue"]

        if len(series) >= MIN_POINTS_FOR_SEASONAL_MODEL:
            method = "holt_winters_seasonal"
            forecast_values, resid_std = self._holt_winters_forecast(series, horizon_days)
        else:
            method = "weighted_moving_average_trend"
            forecast_values, resid_std = self._fallback_forecast(series, horizon_days)

        last_date = series.index[-1]
        points = []
        for i, value in enumerate(forecast_values, start=1):
            forecast_date = (last_date + timedelta(days=i)).date()
            margin = 1.96 * resid_std  # ~95% band assuming normal residuals
            points.append(
                {
                    "date": forecast_date,
                    "forecast_revenue": max(0.0, round(float(value), 2)),
                    "lower_bound": max(0.0, round(float(value - margin), 2)),
                    "upper_bound": round(float(value + margin), 2),
                }
            )
        return method, points

    @staticmethod
    def _holt_winters_forecast(series: pd.Series, horizon: int) -> tuple[np.ndarray, float]:
        model = ExponentialSmoothing(
            series,
            trend="add",
            seasonal="add",
            seasonal_periods=7,
            initialization_method="estimated",
        ).fit(optimized=True)
        forecast = model.forecast(horizon).to_numpy()
        resid_std = float(np.std(model.resid)) if len(model.resid) else float(series.std())
        return forecast, resid_std

    @staticmethod
    def _fallback_forecast(series: pd.Series, horizon: int) -> tuple[np.ndarray, float]:
        # Simple linear trend fit over available points + last-week average level.
        y = series.to_numpy()
        x = np.arange(len(y))
        if len(y) >= 2:
            slope, intercept = np.polyfit(x, y, 1)
        else:
            slope, intercept = 0.0, y[-1] if len(y) else 0.0
        future_x = np.arange(len(y), len(y) + horizon)
        forecast = slope * future_x + intercept
        resid_std = float(np.std(y - (slope * x + intercept))) if len(y) > 1 else 0.0
        return forecast, resid_std
