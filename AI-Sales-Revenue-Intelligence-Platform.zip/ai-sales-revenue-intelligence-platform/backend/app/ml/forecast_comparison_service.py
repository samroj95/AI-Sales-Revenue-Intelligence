"""
Forecast ensemble comparison service.

Design decision
----------------
Rather than picking one forecasting algorithm dogmatically, the platform
backtests all four candidates (Holt-Winters, Prophet, ARIMA/SARIMAX,
XGBoost) against a held-out tail of actual history and scores them with
MAPE (Mean Absolute Percentage Error) and RMSE -- the two metrics
revenue-management teams actually use to evaluate forecast quality. The
model with the lowest MAPE on the backtest window is recommended, and
callers can still request any individual model directly. This mirrors
how a real forecasting system is validated before being trusted for
budget planning: you never deploy a model on faith, you prove it beat
the alternatives on recent held-out data first.
"""
import numpy as np
import pandas as pd
from loguru import logger

from app.ml.arima_service import ArimaForecastingService
from app.ml.forecasting_service import ForecastingService
from app.ml.prophet_service import ProphetForecastingService
from app.ml.xgboost_service import XGBoostForecastingService

MIN_BACKTEST_HISTORY = 45
BACKTEST_HORIZON = 7


def _mape(actual: np.ndarray, predicted: np.ndarray) -> float:
    mask = actual != 0
    if not mask.any():
        return float("nan")
    return float(np.mean(np.abs((actual[mask] - predicted[mask]) / actual[mask])) * 100)


def _rmse(actual: np.ndarray, predicted: np.ndarray) -> float:
    return float(np.sqrt(np.mean((actual - predicted) ** 2)))


class ForecastComparisonService:
    def __init__(self) -> None:
        self._holt_winters = ForecastingService()
        self._prophet = ProphetForecastingService()
        self._arima = ArimaForecastingService()
        self._xgboost = XGBoostForecastingService()

    def _run_model(self, name: str, history: list[dict], horizon: int) -> list[dict] | None:
        try:
            if name == "holt_winters":
                _, points = self._holt_winters.forecast(history, horizon)
                return points
            if name == "prophet":
                return self._prophet.forecast(history, horizon)
            if name == "arima":
                return self._arima.forecast(history, horizon)
            if name == "xgboost":
                return self._xgboost.forecast(history, horizon)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Model '{}' failed during forecasting: {}", name, exc)
            return None
        return None

    def backtest_and_forecast(self, history: list[dict], horizon_days: int = 14) -> dict:
        model_names = ["holt_winters", "prophet", "arima", "xgboost"]

        backtest_scores: dict[str, dict] = {}
        if len(history) >= MIN_BACKTEST_HISTORY:
            train = history[: -BACKTEST_HORIZON]
            test = history[-BACKTEST_HORIZON:]
            actual = np.array([t["total_revenue"] for t in test])

            for name in model_names:
                points = self._run_model(name, train, BACKTEST_HORIZON)
                if not points:
                    backtest_scores[name] = {"mape": None, "rmse": None, "status": "failed"}
                    continue
                predicted = np.array([p["forecast_revenue"] for p in points[: len(test)]])
                backtest_scores[name] = {
                    "mape": round(_mape(actual, predicted), 2),
                    "rmse": round(_rmse(actual, predicted), 2),
                    "status": "ok",
                }
        else:
            for name in model_names:
                backtest_scores[name] = {"mape": None, "rmse": None, "status": "insufficient_history"}

        # Recommend the model with the lowest MAPE among those that ran successfully.
        valid_scores = {k: v["mape"] for k, v in backtest_scores.items() if v["mape"] is not None}
        recommended_model = min(valid_scores, key=valid_scores.get) if valid_scores else "holt_winters"

        # Generate the final forward-looking forecast with every model that succeeds,
        # trained on the FULL history (not the backtest split).
        forecasts = {}
        for name in model_names:
            points = self._run_model(name, history, horizon_days)
            if points:
                forecasts[name] = points

        return {
            "backtest_scores": backtest_scores,
            "recommended_model": recommended_model,
            "forecasts": forecasts,
        }
