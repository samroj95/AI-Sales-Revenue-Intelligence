"""
Revenue anomaly detection service.

Design decision
----------------
Two interchangeable strategies are exposed behind one interface
(Strategy pattern):

  * "zscore"  -- rolling z-score against a trailing window. Cheap,
    explainable ("this day is 3.2 standard deviations from its recent
    baseline"), ideal for a real-time dashboard tooltip. This is the
    default because revenue managers need to *trust and explain* why a
    day was flagged, not just get a black-box label.
  * "isolation_forest" -- scikit-learn's IsolationForest over multiple
    engineered features (revenue, occupancy, ADR) for multivariate
    anomalies a simple z-score would miss (e.g. high occupancy but
    abnormally low ADR, indicating a pricing error).

Both are production-realistic techniques used in revenue-management and
fraud-style anomaly detection, and swapping between them requires no
change to the calling API endpoint (Open/Closed Principle).
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest

ROLLING_WINDOW = 14


def _severity(z: float) -> str:
    az = abs(z)
    if az >= 3:
        return "severe"
    if az >= 2:
        return "moderate"
    return "normal"


class AnomalyDetectionService:
    def detect(
        self, history: list[dict], method: str = "zscore"
    ) -> tuple[int, list[dict]]:
        if not history:
            return 0, []

        df = pd.DataFrame(history)
        df["date"] = pd.to_datetime(df["date"])
        df = df.sort_values("date").reset_index(drop=True)

        if method == "isolation_forest" and {"occupancy_rate", "adr"}.issubset(df.columns):
            points = self._isolation_forest(df)
        else:
            points = self._zscore(df)

        anomalies = sum(1 for p in points if p["is_anomaly"])
        return anomalies, points

    @staticmethod
    def _zscore(df: pd.DataFrame) -> list[dict]:
        revenue = df["total_revenue"].astype(float)
        rolling_mean = revenue.rolling(ROLLING_WINDOW, min_periods=3).mean()
        rolling_std = revenue.rolling(ROLLING_WINDOW, min_periods=3).std().replace(0, np.nan)

        z_scores = ((revenue - rolling_mean) / rolling_std).fillna(0)

        points = []
        for i in range(len(df)):
            z = float(z_scores.iloc[i])
            points.append(
                {
                    "date": df["date"].iloc[i].date(),
                    "total_revenue": float(revenue.iloc[i]),
                    "z_score": round(z, 3),
                    "is_anomaly": abs(z) >= 2.0,
                    "severity": _severity(z),
                }
            )
        return points

    @staticmethod
    def _isolation_forest(df: pd.DataFrame) -> list[dict]:
        features = df[["total_revenue", "occupancy_rate", "adr"]].astype(float).fillna(0)
        model = IsolationForest(
            n_estimators=200, contamination=0.08, random_state=42
        )
        model.fit(features)
        raw_scores = model.decision_function(features)  # higher = more normal
        preds = model.predict(features)  # -1 anomaly, 1 normal

        # Normalize decision_function into a z-score-like scale for the API contract.
        normalized = (raw_scores.mean() - raw_scores) / (raw_scores.std() + 1e-9)

        points = []
        for i in range(len(df)):
            z = float(normalized[i])
            points.append(
                {
                    "date": df["date"].iloc[i].date(),
                    "total_revenue": float(df["total_revenue"].iloc[i]),
                    "z_score": round(z, 3),
                    "is_anomaly": bool(preds[i] == -1),
                    "severity": _severity(z),
                }
            )
        return points
