"""
XGBoost forecasting service.

Design decision
----------------
Unlike Holt-Winters/ARIMA/Prophet (which model the series directly),
XGBoost needs the time series reframed as a supervised learning problem:
lag features (t-1, t-7, t-14), calendar features (day-of-week, month,
is_weekend), and rolling statistics become the feature matrix `X`, with
`total_revenue` as the target `y`. This lets a tree ensemble capture
non-linear interactions (e.g. "Saturday in July behaves differently than
Saturday in January") that linear/additive models can miss.

Forecasting beyond day 1 is done recursively: predict day t+1, append it
to the feature history, recompute lag features, predict t+2, and so on.
This is the standard approach for applying tabular ML models to
multi-step forecasting and is clearly weaker for long horizons (error
compounds), which is exactly what the ensemble comparison's backtest
is meant to surface.
"""
import numpy as np
import pandas as pd
from xgboost import XGBRegressor

LAGS = [1, 2, 3, 7, 14]
ROLLING_WINDOWS = [7, 14]


def _build_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for lag in LAGS:
        df[f"lag_{lag}"] = df["total_revenue"].shift(lag)
    for window in ROLLING_WINDOWS:
        df[f"rolling_mean_{window}"] = df["total_revenue"].shift(1).rolling(window).mean()
    df["day_of_week"] = df.index.dayofweek
    df["is_weekend"] = df["day_of_week"].isin([4, 5]).astype(int)
    df["month"] = df.index.month
    return df


class XGBoostForecastingService:
    def forecast(self, history: list[dict], horizon_days: int = 14) -> list[dict]:
        df = pd.DataFrame(history)
        df["date"] = pd.to_datetime(df["date"])
        df = df.set_index("date").asfreq("D")
        df["total_revenue"] = df["total_revenue"].interpolate().fillna(method="bfill")

        feature_df = _build_features(df).dropna()
        feature_cols = [c for c in feature_df.columns if c != "total_revenue"]

        model = XGBRegressor(
            n_estimators=300,
            max_depth=4,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            objective="reg:squarederror",
        )
        model.fit(feature_df[feature_cols], feature_df["total_revenue"])

        # Residual std on training set, used for an approximate confidence band
        # (XGBoost point-predicts by default; quantile regression would be the
        # production upgrade path for calibrated intervals).
        train_preds = model.predict(feature_df[feature_cols])
        resid_std = float(np.std(feature_df["total_revenue"].to_numpy() - train_preds))

        working_series = df["total_revenue"].copy()
        points = []
        last_date = working_series.index[-1]

        for step in range(1, horizon_days + 1):
            next_date = last_date + pd.Timedelta(days=step)
            extended = working_series.copy()
            extended.loc[next_date] = np.nan
            feat_row = _build_features(extended.to_frame("total_revenue")).iloc[[-1]]
            pred = float(model.predict(feat_row[feature_cols])[0])
            pred = max(0.0, pred)

            working_series.loc[next_date] = pred
            margin = 1.96 * resid_std
            points.append(
                {
                    "date": next_date.date(),
                    "forecast_revenue": round(pred, 2),
                    "lower_bound": max(0.0, round(pred - margin, 2)),
                    "upper_bound": round(pred + margin, 2),
                }
            )

        return points
