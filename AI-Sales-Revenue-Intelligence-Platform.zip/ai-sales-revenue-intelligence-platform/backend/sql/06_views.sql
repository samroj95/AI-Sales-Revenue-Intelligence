-- =============================================================================
-- Module 4: SQL Analytics -- Views
-- These views are the recommended DirectQuery / Import targets for Power
-- BI (see powerbi/README.md): they pre-join and pre-aggregate so Power
-- BI's data model stays thin and refreshes stay fast.
-- =============================================================================

CREATE OR REPLACE VIEW vw_daily_hotel_performance AS
SELECT
    r.hotel_id,
    h.name AS hotel_name,
    h.city,
    h.country,
    r.date,
    r.total_revenue,
    r.room_revenue,
    r.occupancy_rate,
    r.adr,
    r.revpar,
    COALESCE(rs.total_revenue, 0) AS restaurant_revenue,
    COALESCE(sp.total_revenue, 0) AS spa_revenue,
    r.total_revenue + COALESCE(rs.total_revenue, 0) + COALESCE(sp.total_revenue, 0) AS grand_total_revenue
FROM revenue_records r
JOIN hotels h ON h.id = r.hotel_id
LEFT JOIN restaurant_sales rs ON rs.hotel_id = r.hotel_id AND rs.date = r.date
LEFT JOIN spa_sales sp ON sp.hotel_id = r.hotel_id AND sp.date = r.date;

CREATE OR REPLACE VIEW vw_monthly_hotel_kpis AS
SELECT
    hotel_id,
    DATE_TRUNC('month', date)::date AS month,
    SUM(total_revenue) AS total_revenue,
    ROUND(AVG(occupancy_rate), 2) AS avg_occupancy_rate,
    ROUND(AVG(adr), 2) AS avg_adr,
    ROUND(AVG(revpar), 2) AS avg_revpar
FROM revenue_records
GROUP BY hotel_id, DATE_TRUNC('month', date);

CREATE OR REPLACE VIEW vw_booking_channel_summary AS
SELECT
    hotel_id,
    channel,
    COUNT(*) AS booking_count,
    SUM(total_amount) AS total_revenue,
    ROUND(AVG(total_amount), 2) AS avg_booking_value,
    ROUND(100.0 * COUNT(*) FILTER (WHERE status = 'cancelled') / COUNT(*), 2) AS cancellation_rate_pct
FROM bookings
GROUP BY hotel_id, channel;

CREATE OR REPLACE VIEW vw_customer_summary AS
SELECT
    id AS customer_id,
    full_name,
    country,
    is_loyalty_member,
    loyalty_tier,
    lifetime_value,
    total_stays,
    is_repeat_customer
FROM customers;

CREATE OR REPLACE VIEW vw_hotel_reputation AS
SELECT
    hotel_id,
    ROUND(AVG(rating), 2) AS avg_rating,
    COUNT(*) AS total_reviews,
    COUNT(*) FILTER (WHERE sentiment = 'positive') AS positive_reviews,
    COUNT(*) FILTER (WHERE sentiment = 'negative') AS negative_reviews
FROM reviews
GROUP BY hotel_id;
