-- =============================================================================
-- Module 4: SQL Analytics -- Restaurant & Spa Queries
-- =============================================================================

-- 25. Restaurant sales by hotel, last 30 days
SELECT h.name, SUM(rs.total_revenue) AS restaurant_revenue, SUM(rs.covers_served) AS covers
FROM restaurant_sales rs
JOIN hotels h ON h.id = rs.hotel_id
WHERE rs.date >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY h.name
ORDER BY restaurant_revenue DESC;

-- 26. Average check size trend by month
SELECT hotel_id, DATE_TRUNC('month', date) AS month, ROUND(AVG(avg_check_size), 2) AS avg_check_size
FROM restaurant_sales
GROUP BY hotel_id, DATE_TRUNC('month', date)
ORDER BY hotel_id, month;

-- 27. Food vs beverage revenue mix
SELECT hotel_id,
       SUM(food_revenue) AS food_revenue,
       SUM(beverage_revenue) AS beverage_revenue,
       ROUND(100.0 * SUM(beverage_revenue) / NULLIF(SUM(food_revenue) + SUM(beverage_revenue), 0), 2) AS beverage_mix_pct
FROM restaurant_sales
GROUP BY hotel_id;

-- 28. Spa revenue by hotel
SELECT h.name, SUM(s.total_revenue) AS spa_revenue, SUM(s.treatments_booked) AS treatments
FROM spa_sales s
JOIN hotels h ON h.id = s.hotel_id
GROUP BY h.name
ORDER BY spa_revenue DESC;

-- 29. Spa revenue per available room (ancillary RevPAR-style metric)
SELECT s.hotel_id, ROUND(SUM(s.total_revenue) / h.total_rooms, 2) AS spa_revenue_per_room
FROM spa_sales s
JOIN hotels h ON h.id = s.hotel_id
GROUP BY s.hotel_id, h.total_rooms
ORDER BY spa_revenue_per_room DESC;

-- 30. Ancillary revenue (restaurant + spa) as % of total hotel revenue
WITH ancillary AS (
    SELECT hotel_id, SUM(total_revenue) AS ancillary_revenue FROM (
        SELECT hotel_id, total_revenue FROM restaurant_sales
        UNION ALL
        SELECT hotel_id, total_revenue FROM spa_sales
    ) combined
    GROUP BY hotel_id
),
room_rev AS (
    SELECT hotel_id, SUM(total_revenue) AS room_total FROM revenue_records GROUP BY hotel_id
)
SELECT r.hotel_id, r.room_total, COALESCE(a.ancillary_revenue, 0) AS ancillary_revenue,
       ROUND(100.0 * COALESCE(a.ancillary_revenue, 0) / NULLIF(r.room_total + COALESCE(a.ancillary_revenue, 0), 0), 2) AS ancillary_pct_of_total
FROM room_rev r
LEFT JOIN ancillary a ON a.hotel_id = r.hotel_id;

-- 31. Top 5 highest-revenue restaurant days (outlier/peak detection)
SELECT hotel_id, date, total_revenue
FROM restaurant_sales
ORDER BY total_revenue DESC
LIMIT 5;
