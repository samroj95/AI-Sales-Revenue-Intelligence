-- =============================================================================
-- Module 4: SQL Analytics -- Customer, Loyalty & Reviews Queries
-- =============================================================================

-- 32. Repeat customer % overall
SELECT ROUND(100.0 * COUNT(*) FILTER (WHERE total_stays >= 2) / NULLIF(COUNT(*), 0), 2) AS repeat_customer_pct
FROM customers;

-- 33. Top 20 customers by lifetime value
SELECT full_name, email, country, lifetime_value, total_stays
FROM customers
ORDER BY lifetime_value DESC
LIMIT 20;

-- 34. Loyalty tier distribution and average CLV per tier
SELECT loyalty_tier, COUNT(*) AS members, ROUND(AVG(lifetime_value), 2) AS avg_clv
FROM customers
WHERE is_loyalty_member = TRUE
GROUP BY loyalty_tier
ORDER BY avg_clv DESC;

-- 35. New vs returning guest revenue split (per hotel, current year)
SELECT b.hotel_id,
       SUM(b.total_amount) FILTER (WHERE c.total_stays = 1) AS new_guest_revenue,
       SUM(b.total_amount) FILTER (WHERE c.total_stays >= 2) AS returning_guest_revenue
FROM bookings b
JOIN customers c ON c.id = b.customer_id
WHERE EXTRACT(YEAR FROM b.check_in) = EXTRACT(YEAR FROM CURRENT_DATE)
  AND b.status NOT IN ('cancelled', 'no_show')
GROUP BY b.hotel_id;

-- 36. Customer acquisition by country (loyalty sign-ups per month)
SELECT DATE_TRUNC('month', join_date) AS month, country, COUNT(*) AS new_members
FROM customers
WHERE is_loyalty_member = TRUE AND join_date IS NOT NULL
GROUP BY DATE_TRUNC('month', join_date), country
ORDER BY month, new_members DESC;

-- 37. Average review rating by hotel
SELECT h.name, ROUND(AVG(rv.rating), 2) AS avg_rating, COUNT(*) AS review_count
FROM reviews rv
JOIN hotels h ON h.id = rv.hotel_id
GROUP BY h.name
ORDER BY avg_rating DESC;

-- 38. Sentiment breakdown by hotel
SELECT hotel_id, sentiment, COUNT(*) AS review_count,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (PARTITION BY hotel_id), 2) AS pct_of_reviews
FROM reviews
GROUP BY hotel_id, sentiment
ORDER BY hotel_id, review_count DESC;

-- 39. Review rating trend by month (is reputation improving or declining?)
SELECT hotel_id, DATE_TRUNC('month', review_date) AS month, ROUND(AVG(rating), 2) AS avg_rating
FROM reviews
GROUP BY hotel_id, DATE_TRUNC('month', review_date)
ORDER BY hotel_id, month;

-- 40. Review source mix (which OTA/platform drives the most review volume?)
SELECT source, COUNT(*) AS review_count, ROUND(AVG(rating), 2) AS avg_rating
FROM reviews
GROUP BY source
ORDER BY review_count DESC;

-- 41. Hotels with declining review sentiment (negative reviews trending up month-over-month)
WITH monthly_negative AS (
    SELECT hotel_id, DATE_TRUNC('month', review_date) AS month,
           COUNT(*) FILTER (WHERE sentiment = 'negative') AS negative_count,
           COUNT(*) AS total_count
    FROM reviews
    GROUP BY hotel_id, DATE_TRUNC('month', review_date)
)
SELECT hotel_id, month,
       ROUND(100.0 * negative_count / NULLIF(total_count, 0), 2) AS negative_pct,
       ROUND(100.0 * negative_count / NULLIF(total_count, 0), 2)
         - LAG(ROUND(100.0 * negative_count / NULLIF(total_count, 0), 2))
           OVER (PARTITION BY hotel_id ORDER BY month) AS mom_change_pct_points
FROM monthly_negative
ORDER BY hotel_id, month;
