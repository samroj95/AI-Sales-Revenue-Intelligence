-- =============================================================================
-- Module 4: SQL Analytics -- Stored Procedure
-- Design decision: the ETL pipeline (app/etl/etl_pipeline.py) does this
-- aggregation in Pandas for portability and testability, but a pure-SQL
-- equivalent is included here to demonstrate stored-procedure competency
-- and as a fallback that can run directly via a DB cron job (pg_cron)
-- without invoking the Python service at all.
-- =============================================================================

CREATE OR REPLACE PROCEDURE refresh_daily_revenue(p_hotel_id INT)
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO revenue_records (hotel_id, date, room_revenue, fnb_revenue, other_revenue,
                                  total_revenue, rooms_sold, occupancy_rate, adr, revpar,
                                  created_at, updated_at)
    SELECT
        b.hotel_id,
        b.check_in AS date,
        SUM(b.total_amount) AS room_revenue,
        0 AS fnb_revenue,
        0 AS other_revenue,
        SUM(b.total_amount) AS total_revenue,
        COUNT(*) AS rooms_sold,
        ROUND(100.0 * COUNT(*) / h.total_rooms, 2) AS occupancy_rate,
        ROUND(SUM(b.total_amount) / NULLIF(COUNT(*), 0), 2) AS adr,
        ROUND(SUM(b.total_amount) / h.total_rooms, 2) AS revpar,
        NOW(), NOW()
    FROM bookings b
    JOIN hotels h ON h.id = b.hotel_id
    WHERE b.hotel_id = p_hotel_id
      AND b.status NOT IN ('cancelled', 'no_show')
    GROUP BY b.hotel_id, b.check_in, h.total_rooms
    ON CONFLICT (hotel_id, date) DO UPDATE SET
        room_revenue = EXCLUDED.room_revenue,
        total_revenue = EXCLUDED.total_revenue,
        rooms_sold = EXCLUDED.rooms_sold,
        occupancy_rate = EXCLUDED.occupancy_rate,
        adr = EXCLUDED.adr,
        revpar = EXCLUDED.revpar,
        updated_at = NOW();
END;
$$;

-- Usage: CALL refresh_daily_revenue(1);
