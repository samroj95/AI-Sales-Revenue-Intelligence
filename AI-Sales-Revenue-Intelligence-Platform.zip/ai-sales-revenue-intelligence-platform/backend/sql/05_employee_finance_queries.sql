-- =============================================================================
-- Module 4: SQL Analytics -- Employee Productivity & Finance Queries
-- =============================================================================

-- 42. Employee productivity by department (revenue generated, tasks completed)
SELECT department, COUNT(*) AS headcount,
       SUM(revenue_generated_mtd) AS total_revenue_generated,
       ROUND(AVG(tasks_completed_mtd), 1) AS avg_tasks_completed
FROM employees
GROUP BY department
ORDER BY total_revenue_generated DESC;

-- 43. Top 10 employees by revenue generated month-to-date
SELECT e.full_name, e.department, h.name AS hotel_name, e.revenue_generated_mtd
FROM employees e
JOIN hotels h ON h.id = e.hotel_id
ORDER BY e.revenue_generated_mtd DESC
LIMIT 10;

-- 44. Revenue generated per employee, ranked within department (window function)
SELECT hotel_id, department, full_name, revenue_generated_mtd,
       RANK() OVER (PARTITION BY department ORDER BY revenue_generated_mtd DESC) AS dept_rank
FROM employees;

-- 45. Headcount by hotel and department (staffing overview)
SELECT h.name, e.department, COUNT(*) AS headcount
FROM employees e
JOIN hotels h ON h.id = e.hotel_id
GROUP BY h.name, e.department
ORDER BY h.name, headcount DESC;

-- 46. Total portfolio revenue reconciliation: rooms + restaurant + spa (finance close view)
SELECT h.name,
       COALESCE(SUM(rv.total_revenue), 0) AS room_revenue,
       COALESCE((SELECT SUM(total_revenue) FROM restaurant_sales WHERE hotel_id = h.id), 0) AS restaurant_revenue,
       COALESCE((SELECT SUM(total_revenue) FROM spa_sales WHERE hotel_id = h.id), 0) AS spa_revenue,
       COALESCE(SUM(rv.total_revenue), 0)
         + COALESCE((SELECT SUM(total_revenue) FROM restaurant_sales WHERE hotel_id = h.id), 0)
         + COALESCE((SELECT SUM(total_revenue) FROM spa_sales WHERE hotel_id = h.id), 0) AS grand_total_revenue
FROM hotels h
LEFT JOIN revenue_records rv ON rv.hotel_id = h.id
GROUP BY h.id, h.name
ORDER BY grand_total_revenue DESC;

-- 47. Discount leakage: total discounts given vs gross booking value, by channel
SELECT channel,
       SUM(total_amount + discount_amount) AS gross_value,
       SUM(discount_amount) AS total_discounts,
       ROUND(100.0 * SUM(discount_amount) / NULLIF(SUM(total_amount + discount_amount), 0), 2) AS discount_pct
FROM bookings
WHERE status NOT IN ('cancelled', 'no_show')
GROUP BY channel
ORDER BY discount_pct DESC;

-- 48. Year-to-date revenue vs prior year same period (YoY comparison)
WITH this_year AS (
    SELECT hotel_id, SUM(total_revenue) AS revenue
    FROM revenue_records
    WHERE date BETWEEN DATE_TRUNC('year', CURRENT_DATE) AND CURRENT_DATE
    GROUP BY hotel_id
),
last_year AS (
    SELECT hotel_id, SUM(total_revenue) AS revenue
    FROM revenue_records
    WHERE date BETWEEN DATE_TRUNC('year', CURRENT_DATE) - INTERVAL '1 year'
                    AND CURRENT_DATE - INTERVAL '1 year'
    GROUP BY hotel_id
)
SELECT t.hotel_id, t.revenue AS ytd_revenue, l.revenue AS prior_ytd_revenue,
       ROUND(100.0 * (t.revenue - l.revenue) / NULLIF(l.revenue, 0), 2) AS yoy_growth_pct
FROM this_year t
LEFT JOIN last_year l ON l.hotel_id = t.hotel_id;

-- 49. Average revenue per available room-night across the whole portfolio (single KPI)
SELECT ROUND(SUM(total_revenue) / NULLIF(SUM(rooms_sold), 0), 2) AS blended_adr,
       ROUND(AVG(revpar), 2) AS blended_avg_revpar
FROM revenue_records;

-- 50. Data quality audit: revenue rows with zero or negative values (should be empty in a healthy pipeline)
SELECT * FROM revenue_records WHERE total_revenue <= 0 OR occupancy_rate < 0 OR occupancy_rate > 100;
