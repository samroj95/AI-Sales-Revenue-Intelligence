-- =============================================================================
-- Module 4: SQL Analytics -- Indexes
-- Design decision: beyond SQLAlchemy's `index=True` columns (already
-- created via ORM metadata), these composite/partial indexes target the
-- specific access patterns of the dashboard and ML queries above --
-- (hotel_id, date) range scans dominate this workload.
-- =============================================================================

CREATE INDEX IF NOT EXISTS ix_revenue_records_hotel_date
    ON revenue_records (hotel_id, date);

CREATE INDEX IF NOT EXISTS ix_bookings_hotel_checkin
    ON bookings (hotel_id, check_in);

CREATE INDEX IF NOT EXISTS ix_bookings_status_partial
    ON bookings (hotel_id)
    WHERE status IN ('cancelled', 'no_show');

CREATE INDEX IF NOT EXISTS ix_restaurant_sales_hotel_date
    ON restaurant_sales (hotel_id, date);

CREATE INDEX IF NOT EXISTS ix_spa_sales_hotel_date
    ON spa_sales (hotel_id, date);

CREATE INDEX IF NOT EXISTS ix_reviews_hotel_date
    ON reviews (hotel_id, review_date);

CREATE INDEX IF NOT EXISTS ix_customers_lifetime_value
    ON customers (lifetime_value DESC);
