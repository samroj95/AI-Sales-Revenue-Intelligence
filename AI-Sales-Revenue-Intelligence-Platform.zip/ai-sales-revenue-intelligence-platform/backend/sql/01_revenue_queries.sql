-- =============================================================================
-- Module 4: SQL Analytics -- Revenue Queries
-- Run against PostgreSQL. Demonstrates CTEs, window functions, and
-- aggregate reporting typical of a hotel revenue-management SQL layer.
-- =============================================================================

-- 1. Top revenue-generating hotels (last 90 days)
SELECT h.id, h.name, h.city, SUM(r.total_revenue) AS total_revenue
FROM revenue_records r
JOIN hotels h ON h.id = r.hotel_id
WHERE r.date >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY h.id, h.name, h.city
ORDER BY total_revenue DESC;

-- 2. Monthly revenue trend per hotel
SELECT h.name AS hotel_name,
       DATE_TRUNC('month', r.date) AS month,
       SUM(r.total_revenue) AS monthly_revenue
FROM revenue_records r
JOIN hotels h ON h.id = r.hotel_id
GROUP BY h.name, DATE_TRUNC('month', r.date)
ORDER BY h.name, month;

-- 3. Month-over-month revenue growth % (window function: LAG)
WITH monthly AS (
    SELECT hotel_id, DATE_TRUNC('month', date) AS month, SUM(total_revenue) AS revenue
    FROM revenue_records
    GROUP BY hotel_id, DATE_TRUNC('month', date)
)
SELECT hotel_id, month, revenue,
       LAG(revenue) OVER (PARTITION BY hotel_id ORDER BY month) AS prev_month_revenue,
       ROUND(
         100.0 * (revenue - LAG(revenue) OVER (PARTITION BY hotel_id ORDER BY month))
         / NULLIF(LAG(revenue) OVER (PARTITION BY hotel_id ORDER BY month), 0), 2
       ) AS mom_growth_pct
FROM monthly
ORDER BY hotel_id, month;

-- 4. Running (cumulative) revenue per hotel year-to-date (window function: SUM OVER)
SELECT hotel_id, date, total_revenue,
       SUM(total_revenue) OVER (PARTITION BY hotel_id ORDER BY date
                                 ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS ytd_cumulative_revenue
FROM revenue_records
WHERE date >= DATE_TRUNC('year', CURRENT_DATE);

-- 5. 7-day rolling average revenue (window function: moving average)
SELECT hotel_id, date, total_revenue,
       ROUND(AVG(total_revenue) OVER (
           PARTITION BY hotel_id ORDER BY date
           ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
       ), 2) AS rolling_7day_avg_revenue
FROM revenue_records
ORDER BY hotel_id, date;

-- 6. Revenue rank per hotel among portfolio, per month (window function: RANK)
WITH monthly AS (
    SELECT hotel_id, DATE_TRUNC('month', date) AS month, SUM(total_revenue) AS revenue
    FROM revenue_records
    GROUP BY hotel_id, DATE_TRUNC('month', date)
)
SELECT hotel_id, month, revenue,
       RANK() OVER (PARTITION BY month ORDER BY revenue DESC) AS revenue_rank_in_month
FROM monthly
ORDER BY month, revenue_rank_in_month;

-- 7. Average booking value overall and by channel
SELECT channel, ROUND(AVG(total_amount), 2) AS avg_booking_value, COUNT(*) AS bookings
FROM bookings
WHERE status NOT IN ('cancelled', 'no_show')
GROUP BY channel
ORDER BY avg_booking_value DESC;

-- 8. Weekend vs weekday revenue split
SELECT hotel_id,
       SUM(CASE WHEN EXTRACT(DOW FROM date) IN (5, 6) THEN total_revenue ELSE 0 END) AS weekend_revenue,
       SUM(CASE WHEN EXTRACT(DOW FROM date) NOT IN (5, 6) THEN total_revenue ELSE 0 END) AS weekday_revenue
FROM revenue_records
GROUP BY hotel_id;

-- 9. Revenue by room type (join through bookings -> room_types)
SELECT rt.name AS room_type, SUM(b.total_amount) AS total_revenue, COUNT(*) AS bookings
FROM bookings b
JOIN room_types rt ON rt.id = b.room_type_id
WHERE b.status NOT IN ('cancelled', 'no_show')
GROUP BY rt.name
ORDER BY total_revenue DESC;

-- 10. Best-performing room category per hotel (window function: ROW_NUMBER + partition)
WITH room_revenue AS (
    SELECT b.hotel_id, rt.name AS room_type, SUM(b.total_amount) AS revenue
    FROM bookings b
    JOIN room_types rt ON rt.id = b.room_type_id
    WHERE b.status NOT IN ('cancelled', 'no_show')
    GROUP BY b.hotel_id, rt.name
),
ranked AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY hotel_id ORDER BY revenue DESC) AS rn
    FROM room_revenue
)
SELECT hotel_id, room_type, revenue
FROM ranked
WHERE rn = 1;

-- 11. Total revenue by country of guest origin (top 10)
SELECT c.country, SUM(b.total_amount) AS total_revenue
FROM bookings b
JOIN customers c ON c.id = b.customer_id
WHERE b.status NOT IN ('cancelled', 'no_show')
GROUP BY c.country
ORDER BY total_revenue DESC
LIMIT 10;

-- 12. RevPAR trend, quarter over quarter
SELECT hotel_id, DATE_TRUNC('quarter', date) AS quarter, ROUND(AVG(revpar), 2) AS avg_revpar
FROM revenue_records
GROUP BY hotel_id, DATE_TRUNC('quarter', date)
ORDER BY hotel_id, quarter;

-- 13. ADR vs occupancy correlation input table (for BI scatter plot)
SELECT hotel_id, date, adr, occupancy_rate
FROM revenue_records
ORDER BY hotel_id, date;

-- 14. Days where revenue exceeded the property's 90-day trailing average by >20%
WITH trailing AS (
    SELECT hotel_id, date, total_revenue,
           AVG(total_revenue) OVER (
               PARTITION BY hotel_id ORDER BY date
               ROWS BETWEEN 90 PRECEDING AND 1 PRECEDING
           ) AS trailing_avg
    FROM revenue_records
)
SELECT hotel_id, date, total_revenue, trailing_avg
FROM trailing
WHERE trailing_avg IS NOT NULL AND total_revenue > trailing_avg * 1.2
ORDER BY hotel_id, date;

-- 15. Revenue contribution % of each hotel to total portfolio revenue
WITH totals AS (
    SELECT hotel_id, SUM(total_revenue) AS hotel_revenue FROM revenue_records GROUP BY hotel_id
),
grand_total AS (
    SELECT SUM(hotel_revenue) AS portfolio_revenue FROM totals
)
SELECT t.hotel_id, t.hotel_revenue,
       ROUND(100.0 * t.hotel_revenue / g.portfolio_revenue, 2) AS pct_of_portfolio
FROM totals t CROSS JOIN grand_total g
ORDER BY pct_of_portfolio DESC;
