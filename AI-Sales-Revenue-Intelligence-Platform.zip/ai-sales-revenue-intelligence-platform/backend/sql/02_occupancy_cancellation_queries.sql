-- =============================================================================
-- Module 4: SQL Analytics -- Occupancy & Cancellation Queries
-- =============================================================================

-- 16. Current occupancy % by hotel (most recent date on record)
WITH latest AS (
    SELECT hotel_id, MAX(date) AS max_date FROM revenue_records GROUP BY hotel_id
)
SELECT r.hotel_id, h.name, r.date, r.occupancy_rate
FROM revenue_records r
JOIN latest l ON l.hotel_id = r.hotel_id AND l.max_date = r.date
JOIN hotels h ON h.id = r.hotel_id;

-- 17. Average occupancy by day-of-week (reveals weekly demand pattern)
SELECT TO_CHAR(date, 'Day') AS day_of_week, ROUND(AVG(occupancy_rate), 2) AS avg_occupancy
FROM revenue_records
GROUP BY TO_CHAR(date, 'Day'), EXTRACT(DOW FROM date)
ORDER BY EXTRACT(DOW FROM date);

-- 18. Hotels with occupancy below 55% in the trailing 30 days (alert trigger source query)
SELECT hotel_id, ROUND(AVG(occupancy_rate), 2) AS avg_occupancy_30d
FROM revenue_records
WHERE date >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY hotel_id
HAVING AVG(occupancy_rate) < 55;

-- 19. Highest-cancellation-rate hotels
SELECT h.name, COUNT(*) FILTER (WHERE b.status = 'cancelled') AS cancellations,
       COUNT(*) AS total_bookings,
       ROUND(100.0 * COUNT(*) FILTER (WHERE b.status = 'cancelled') / COUNT(*), 2) AS cancellation_rate_pct
FROM bookings b
JOIN hotels h ON h.id = b.hotel_id
GROUP BY h.name
ORDER BY cancellation_rate_pct DESC;

-- 20. Cancellation rate trend by month (window function context: month-over-month change)
WITH monthly_cancel AS (
    SELECT hotel_id, DATE_TRUNC('month', booking_date) AS month,
           COUNT(*) FILTER (WHERE status = 'cancelled') AS cancellations,
           COUNT(*) AS total
    FROM bookings
    GROUP BY hotel_id, DATE_TRUNC('month', booking_date)
)
SELECT hotel_id, month,
       ROUND(100.0 * cancellations / NULLIF(total, 0), 2) AS cancellation_rate_pct,
       ROUND(100.0 * cancellations / NULLIF(total, 0), 2)
         - LAG(ROUND(100.0 * cancellations / NULLIF(total, 0), 2))
           OVER (PARTITION BY hotel_id ORDER BY month) AS mom_change_pct_points
FROM monthly_cancel
ORDER BY hotel_id, month;

-- 21. No-show rate by channel
SELECT channel, COUNT(*) FILTER (WHERE status = 'no_show') AS no_shows, COUNT(*) AS total,
       ROUND(100.0 * COUNT(*) FILTER (WHERE status = 'no_show') / COUNT(*), 2) AS no_show_rate_pct
FROM bookings
GROUP BY channel
ORDER BY no_show_rate_pct DESC;

-- 22. Average booking lead time by channel (are OTA bookings last-minute vs corporate?)
SELECT channel, ROUND(AVG(lead_time_days), 1) AS avg_lead_time_days
FROM bookings
GROUP BY channel
ORDER BY avg_lead_time_days DESC;

-- 23. Occupancy percentile ranking across the portfolio (window function: NTILE)
SELECT hotel_id, ROUND(AVG(occupancy_rate), 2) AS avg_occupancy,
       NTILE(4) OVER (ORDER BY AVG(occupancy_rate) DESC) AS occupancy_quartile
FROM revenue_records
GROUP BY hotel_id;

-- 24. Rooms sold vs total capacity utilization gap (identify underused inventory)
SELECT r.hotel_id, h.total_rooms, ROUND(AVG(r.rooms_sold), 1) AS avg_rooms_sold,
       h.total_rooms - ROUND(AVG(r.rooms_sold)) AS avg_unsold_rooms
FROM revenue_records r
JOIN hotels h ON h.id = r.hotel_id
GROUP BY r.hotel_id, h.total_rooms
ORDER BY avg_unsold_rooms DESC;
