#!/usr/bin/env bash
# Convenience wrapper around docker compose for macOS/Linux.
# Usage: ./scripts/start.sh
set -euo pipefail

cd "$(dirname "$0")/.."

if [ ! -f backend/.env ]; then
  echo "backend/.env not found -- copying from backend/.env.example"
  echo "Edit backend/.env with your real secrets before continuing (Ctrl+C now to do that)."
  cp backend/.env.example backend/.env
  sleep 3
fi

docker compose up --build
