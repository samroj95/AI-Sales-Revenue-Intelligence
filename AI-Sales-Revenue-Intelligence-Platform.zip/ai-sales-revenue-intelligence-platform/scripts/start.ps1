# Convenience wrapper around docker compose for Windows PowerShell.
# Usage: .\scripts\start.ps1
# (You may need to run: Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass  first)

$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

if (-not (Test-Path "backend\.env")) {
    Write-Host "backend\.env not found -- copying from backend\.env.example"
    Write-Host "Edit backend\.env with your real secrets before continuing."
    Copy-Item "backend\.env.example" "backend\.env"
    Start-Sleep -Seconds 3
}

docker compose up --build
