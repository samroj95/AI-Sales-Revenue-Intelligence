# Power BI Integration

## Status: NOT IMPLEMENTED (documentation/guidance only)

**Be clear about what this folder actually contains: no `.pbix` file, no
Power BI service workspace, and no automated Power BI deployment exist
in this repository.** What follows is a guide for connecting Power BI
Desktop to this platform's PostgreSQL database yourself. Do not present
this project as having a working Power BI dashboard unless you complete
the steps below and build the report file.

## Why SQL views exist for this (and what IS implemented)

`backend/sql/06_views.sql` creates five PostgreSQL views
(`vw_daily_hotel_performance`, `vw_monthly_hotel_kpis`,
`vw_booking_channel_summary`, `vw_customer_summary`,
`vw_hotel_reputation`) specifically so that a Power BI data model can
connect directly to clean, pre-aggregated tables instead of raw
transactional data. **These views are real and implemented** — you can
run them today with `psql` or any PostgreSQL client. Building the actual
`.pbix` report on top of them is the part that has not been done.

## How to connect Power BI Desktop (steps you would need to run)

1. Install Power BI Desktop (Windows only; see `INSTALLATION_REQUIREMENTS.md`).
2. Ensure the platform's PostgreSQL container is running and reachable
   (`docker compose up db` or the full stack), with port `5432` exposed.
3. In Power BI Desktop: **Get Data → More... → Database → PostgreSQL database**.
4. Server: `localhost:5432` (or your DB host). Database: `sales_revenue_intelligence`.
5. Choose **DirectQuery** (for live dashboards that always reflect the
   latest ETL run) or **Import** (faster report interaction, refreshed on
   a schedule) depending on your needs.
6. Select the five `vw_*` views listed above as your tables.
7. Build relationships in the Power BI model view: `hotel_id` is the
   common key across all five views (star-schema style, hotel as the
   dimension).
8. Recommended report pages, matching the platform's intended structure
   (build these yourself in Power BI):
   - **Executive Overview** — top KPI cards (revenue, occupancy, ADR,
     RevPAR) from `vw_monthly_hotel_kpis`.
   - **Revenue Dashboard** — trend charts from `vw_daily_hotel_performance`.
   - **Sales / Channel Dashboard** — from `vw_booking_channel_summary`.
   - **Customer Dashboard** — from `vw_customer_summary`.
   - **Reputation Dashboard** — from `vw_hotel_reputation`.
   - A **Forecast Dashboard** would require exporting forecast output
     from the `/forecast/{hotel_id}/compare` API (e.g. via Power BI's
     Web/REST connector, or a scheduled export to a table) since
     forecasts are computed in Python, not SQL.

## Suggested DAX measures (write these into your own .pbix)

```dax
Total Revenue = SUM(vw_monthly_hotel_kpis[total_revenue])

Revenue MoM % =
VAR CurrentRevenue = [Total Revenue]
VAR PriorRevenue =
    CALCULATE([Total Revenue], DATEADD(vw_monthly_hotel_kpis[month], -1, MONTH))
RETURN DIVIDE(CurrentRevenue - PriorRevenue, PriorRevenue)

Avg RevPAR = AVERAGE(vw_monthly_hotel_kpis[avg_revpar])

Cancellation Rate % = AVERAGE(vw_booking_channel_summary[cancellation_rate_pct])
```

## If you don't have Power BI Desktop / are not on Windows

The React executive dashboard (`frontend/src/pages/Dashboard.jsx`) is a
fully working, implemented substitute that reads live data from the
same backend APIs and requires no additional software — this is what
actually ships and runs today.
