# API Reference

Base URL: `http://localhost:8000/api/v1` (local) — interactive Swagger
docs are always available at `/api/v1/docs` and are the source of truth
for exact request/response schemas (generated live from the Pydantic
models, so they cannot drift out of sync with the code the way this
document theoretically could).

All endpoints except `/auth/login`, `/auth/refresh`, and `/health`
(root-level, no `/api/v1` prefix) require a `Authorization: Bearer <token>`
header obtained from `/auth/login`.

## Auth (`/auth`)
| Method | Path | Roles | Description |
|---|---|---|---|
| POST | `/auth/login` | any | OAuth2 form login → access + refresh JWT |
| POST | `/auth/refresh` | any (valid refresh token) | Exchange refresh token for a new pair |
| POST | `/auth/register` | admin only | Create a new platform user |
| GET | `/auth/me` | authenticated | Current user profile |

## Data Ingestion (`/upload-data`) — Module 1
| Method | Path | Roles | Description |
|---|---|---|---|
| POST | `/upload-data?dataset_type=...&hotel_id=...` | admin, revenue_manager | Upload a CSV (`bookings`, `customers`, `restaurant`, `spa`, `reviews`, `employees`); cleaned + feature-engineered before loading |

## Hotels
| GET | `/hotels` | authenticated | List portfolio properties |

## Bookings
| Method | Path | Roles |
|---|---|---|
| POST | `/bookings` | admin, revenue_manager, general_manager |
| GET | `/bookings` (filters: hotel_id, channel, status, dates, pagination) | authenticated |
| GET | `/bookings/{id}` | authenticated |

## Revenue & KPIs
| GET | `/revenue/{hotel_id}/timeseries` | authenticated |
| GET | `/revenue/kpis` (hotel_id, date range) | authenticated |

## Forecasting — Module 5
| GET | `/forecast/{hotel_id}?horizon_days=14` | Single-model forecast (Holt-Winters) |
| GET | `/forecast/{hotel_id}/compare?horizon_days=14` | Backtested comparison across Holt-Winters, Prophet, ARIMA, XGBoost with `recommended_model` |

## Anomaly Detection
| GET | `/anomaly/{hotel_id}?method=zscore\|isolation_forest` | authenticated |

## AI Chatbot (RAG) — Module 6
| POST | `/chatbot/query` `{message, hotel_id?}` | authenticated |

## Executive Dashboard — Module 7
| GET | `/dashboard/channel-mix?hotel_id=` | authenticated |
| GET | `/dashboard/top-hotels?limit=5` | authenticated |

## Alerts — Module 8
| GET | `/alerts/check/{hotel_id}` | authenticated — evaluates revenue-drop/occupancy/cancellation rules and dispatches to email/Slack/AI |

## Reports
| GET | `/download-report?hotel_id=&start_date=&end_date=` | authenticated — streams an .xlsx workbook |

## Spec-compatible aliases — Module 9
Thin wrappers over the canonical endpoints above, matching the original
design sketch's naming:

| Alias | Delegates to |
|---|---|
| GET `/get-kpi` | `/revenue/kpis` |
| GET `/get-revenue` | `/revenue/{hotel_id}/timeseries` |
| GET `/get-forecast` | `/forecast/{hotel_id}` |
| GET `/get-dashboard` | bundled KPI + revenue timeseries |
| POST `/chat` | `/chatbot/query` |

## Health & Ops
| GET | `/health` (root, no prefix) | Liveness probe |
| GET | `/metrics` (root, no prefix) | Prometheus metrics |
