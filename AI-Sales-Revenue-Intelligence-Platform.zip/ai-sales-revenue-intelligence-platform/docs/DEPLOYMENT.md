# Deployment Guide: AWS EC2

**Status: documentation only — this describes the recommended path but
has not been executed against a real AWS account as part of this audit.**

## Architecture

```
Internet → Route 53 (DNS) → EC2 (Elastic IP) → Nginx (host, TLS termination)
                                                   ├─→ frontend container (:3000 internal)
                                                   └─→ backend container (:8000 internal)
                                                          └─→ PostgreSQL (RDS recommended, or containerized)
```

## Steps

1. **Launch EC2 instance**: Ubuntu 22.04 LTS, t3.medium or larger (the
   ML/AI dependencies — Prophet, XGBoost, sentence-transformers — are
   memory-hungry at import time; t3.small is not recommended).
2. **Security group**: allow inbound 22 (SSH, your IP only), 80/443
   (HTTP/HTTPS, public), and optionally 3001/9090 restricted to your IP
   if you want remote access to Grafana/Prometheus.
3. **Install Docker**:
   ```bash
   sudo apt update && sudo apt install -y docker.io docker-compose-plugin
   sudo usermod -aG docker $USER   # log out/in to apply
   ```
4. **Clone/copy the project** to the instance (`git clone ...` or `scp`
   the extracted zip).
5. **Database**: for production, use **Amazon RDS for PostgreSQL**
   instead of the `db` container in `docker-compose.yml` — set
   `DATABASE_URL` in `backend/.env` to the RDS endpoint and remove/ignore
   the `db` service. For a lower-cost demo, the containerized `db`
   service with an EBS-backed volume is acceptable.
6. **Configure `.env`**: `cp backend/.env.example backend/.env` and set
   real `SECRET_KEY`, LLM provider credentials, SMTP/Slack alert
   settings, and `ENVIRONMENT=production`, `DEBUG=false`.
7. **Start the stack**:
   ```bash
   docker compose up -d --build
   ```
8. **Install Nginx on the host** (in front of the Docker containers) for
   TLS termination:
   ```bash
   sudo apt install -y nginx certbot python3-certbot-nginx
   ```
   Point Nginx at `localhost:3000` (frontend, which itself proxies
   `/api` to the backend container per `frontend/nginx.conf`):
   ```nginx
   server {
       server_name your-domain.com;
       location / {
           proxy_pass http://localhost:3000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
       }
   }
   ```
9. **TLS**: `sudo certbot --nginx -d your-domain.com`
10. **Verify**: `curl -f http://localhost:8000/health` should return
    `{"status": "ok", ...}` before exposing publicly.

## Monitoring in production

Prometheus/Grafana ship in `docker-compose.yml` for convenience but are
bound to the host's 9090/3001 in this default config — restrict those
ports to your IP via the security group, or better, put them behind
their own authenticated reverse-proxy path rather than exposing
directly.

## Scaling notes (not implemented, for context only)

- The backend Dockerfile runs `uvicorn --workers 2`; increase workers or
  run multiple backend replicas behind an Application Load Balancer for
  more throughput.
- The FAISS vector store for the chatbot's knowledge base is built
  **in-memory, per-process** (see `app/ai/rag_service.py`) — with
  multiple backend replicas, each rebuilds its own copy on first
  request. This is fine at the current knowledge-base size (a handful of
  markdown docs) but would need a shared vector store (pgvector,
  OpenSearch) if that content grows significantly.
